#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from ucmaw.common import UcmawError, write_output
from ucmaw.orchestrator import provision


def main() -> int:
    parser = argparse.ArgumentParser(description="Idempotently provision a dynamic Codex multi-agent workspace")
    parser.add_argument("--plan", required=True)
    parser.add_argument("--project-root")
    parser.add_argument("--backend", choices=["auto", "daemon", "app-server", "none"], default="auto")
    parser.add_argument("--allow-remote-daemon", action="store_true")
    parser.add_argument("--force-init", action="store_true")
    parser.add_argument("--no-threads", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--output")
    args = parser.parse_args()
    try:
        result = provision(
            args.plan,
            args.project_root,
            backend=args.backend,
            allow_remote_daemon=args.allow_remote_daemon,
            force_init=args.force_init,
            no_threads=args.no_threads,
            dry_run=args.dry_run,
        )
        write_output(result, args.output)
        if result["status"] in {"complete", "planned"}:
            return 0
        if result["status"] == "needs_computer_use":
            return 2
        return 1
    except UcmawError as exc:
        write_output({"status": "error", "errors": [str(exc)]}, args.output)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
