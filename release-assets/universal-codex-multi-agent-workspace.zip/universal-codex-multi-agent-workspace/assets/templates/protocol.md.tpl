# Multi-Agent Protocol — {{PROJECT_NAME}}

Managed by `universal-codex-multi-agent-workspace`. Plan digest: `{{PLAN_DIGEST}}`.

## Team

{{TEAM_TABLE}}

## Task contract

Main creates one Markdown task brief per assignment under `.codex/multi-agent/tasks/` using `.codex/multi-agent/task-template.md`. It includes a unique task ID, objective, target agent, transport requirement, optional exact persistent thread, inputs, method boundary, dependencies, acceptance criteria, validation commands, allowed paths, stop conditions, and expected handoff. An agent accepts only tasks consistent with its profile or returns a scoped objection.

Transport requirements:

- `any-delegation`: persistent-thread dispatch is preferred, but a real spawned subagent plus completed wait is an acceptable fallback.
- `persistent-thread`: the exact target `thread_id` must receive and complete the task. A spawned replacement is not success; return `PERSISTENT_THREAD_UNAVAILABLE` if the required tools are not exposed.

## Mandatory delegation gate

- Main is an Orchestrator, not a Solver or routine implementer.
- When a substantive request contains work covered by an available specialist, delegation is required. Do not complete it directly because doing so would be faster.
- Before Main edits a specialist-owned path or generates a specialist deliverable, it must create the specialist's task brief and successfully send the full brief body through Codex subagent collaboration or the persistent thread recorded in `state.json`.
- A worktree, custom-agent profile, initialized thread, readiness acknowledgement, or sidebar entry is not proof of delegation.
- Main waits for every required handoff, checks it against the brief, requests bounded rework when needed, and only then integrates or synthesizes.
- Main may directly edit task briefs, shared specifications, decision records, integration/conflict resolutions, and final acceptance records. It may not originate specialist implementation, plots, paper sections, or independent review findings.
- If no supported dispatch transport is available, return `DELEGATION_UNAVAILABLE` with the missing capability and stop. Do not silently fall back to single-agent execution.

## Direct thread transport

1. Read `.codex/multi-agent/state.json` immediately before dispatch and resolve the selected agent's current `thread_id`, `model`, `effort`, and workspace path.
2. Prefer `send_message_to_thread` for a recorded persistent worker thread. Send the complete brief body and apply the recorded model/effort when supported.
3. Call `wait_threads` for all dispatched thread IDs. Reuse returned cursors, continue waiting on unfinished targets, and wake only on completion or an attention request. Commentary and readiness acknowledgements are not final handoffs.
4. For `any-delegation`, if persistent-thread tools are unavailable, spawn the matching project-scoped custom agent and wait with `wait_agent`. For `persistent-thread`, do not substitute a spawned child.
5. After every required thread returns, inspect the final messages, request bounded follow-up work if needed, then perform the final cross-agent correctness check.

## Behavioral evidence

For the required smoke test, copy `.codex/multi-agent/smoke-test-template.json` to `.codex/multi-agent/smoke-test.json`, replace placeholders with observed dispatch/completion IDs, and validate it with `scripts/validate_smoke.py`. Never record readiness or commentary as completion evidence.

## Ownership and concurrency

- Exclusive owners are the only specialist writers for their claimed paths while a task is active.
- Main may integrate across paths only after the owner hands off or explicitly releases the files.
- Before editing a shared file, announce the intended file and coordinate a single writer.
- Do not edit another worktree or copy uncommitted files between worktrees.

## Git rules

- Each writing specialist works on its managed branch/worktree.
- Do not stash, reset, force-checkout, delete a branch/worktree, rewrite history, commit, push, merge, or open a pull request unless the user or Main explicitly requests that action.
- Preserve unrelated and pre-existing changes.

## Handoff

Return: task ID; status; summary; changed files; validation commands and results; commit SHA if one was explicitly requested; remaining risks; and the exact next action for Main. Main verifies the handoff before integration.

## Model routing

Each initialized or delegated turn must explicitly carry the model and reasoning effort recorded in `team.json`. If the runtime does not advertise the pair, use the runtime default/fallback recorded in `last-report.json`; never infer routing from a UI dropdown.

## Integration order

{{INTEGRATION_ORDER}}

## Shared quality gates

{{SHARED_GATES}}
