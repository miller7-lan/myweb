from __future__ import annotations

import collections
import os
from pathlib import Path
from typing import Any

from .common import resolve_git_root, run


IGNORED_PARTS = {".git", "node_modules", "vendor", "dist", "build", "target", ".venv", "venv"}
MANIFEST_SIGNALS = {
    "package.json": "JavaScript/TypeScript package",
    "pnpm-workspace.yaml": "pnpm workspace",
    "yarn.lock": "Yarn workspace/package",
    "Cargo.toml": "Rust crate/workspace",
    "pyproject.toml": "Python project",
    "requirements.txt": "Python requirements",
    "go.mod": "Go module",
    "pom.xml": "Maven project",
    "build.gradle": "Gradle project",
    "build.gradle.kts": "Gradle Kotlin project",
    "Package.swift": "Swift package",
    "Gemfile": "Ruby project",
    "composer.json": "PHP project",
    "CMakeLists.txt": "C/C++ CMake project",
    "Dockerfile": "Container build",
    "docker-compose.yml": "Docker Compose stack",
    "docker-compose.yaml": "Docker Compose stack",
    "terraform.tf": "Terraform infrastructure",
}
EXTENSION_LANGUAGES = {
    ".py": "Python", ".pyi": "Python", ".ts": "TypeScript", ".tsx": "TypeScript",
    ".js": "JavaScript", ".jsx": "JavaScript", ".rs": "Rust", ".go": "Go",
    ".java": "Java", ".kt": "Kotlin", ".kts": "Kotlin", ".swift": "Swift",
    ".c": "C", ".h": "C/C++", ".cc": "C++", ".cpp": "C++", ".hpp": "C++",
    ".cs": "C#", ".rb": "Ruby", ".php": "PHP", ".scala": "Scala",
    ".ex": "Elixir", ".exs": "Elixir", ".sql": "SQL", ".sh": "Shell",
    ".vue": "Vue", ".svelte": "Svelte", ".dart": "Dart", ".lua": "Lua",
}


def _git_lines(root: Path, args: list[str], *, allow_failure: bool = False) -> list[str]:
    result = run(["git", *args], cwd=root, check=not allow_failure)
    if result.returncode != 0:
        return []
    return [line for line in result.stdout.splitlines() if line.strip()]


def _default_branch(root: Path) -> str | None:
    symbolic = run(
        ["git", "symbolic-ref", "--quiet", "--short", "refs/remotes/origin/HEAD"],
        cwd=root,
        check=False,
    )
    if symbolic.returncode == 0 and symbolic.stdout.strip():
        return symbolic.stdout.strip().split("/", 1)[-1]
    for candidate in ("main", "master"):
        found = run(["git", "show-ref", "--verify", "--quiet", f"refs/heads/{candidate}"], cwd=root, check=False)
        if found.returncode == 0:
            return candidate
    return None


def discover_project(project_root: Path | str) -> dict[str, Any]:
    root = resolve_git_root(project_root)
    raw_files = _git_lines(root, ["ls-files", "-co", "--exclude-standard"])
    files: list[str] = []
    for value in raw_files:
        parts = Path(value).parts
        if not any(part in IGNORED_PARTS for part in parts):
            files.append(value)

    languages: collections.Counter[str] = collections.Counter()
    top_level: collections.Counter[str] = collections.Counter()
    manifests: list[dict[str, str]] = []
    instruction_files: list[str] = []
    ci_files: list[str] = []
    test_files = 0
    doc_files = 0
    total_bytes = 0

    for relative in files[:50000]:
        path = Path(relative)
        extension = path.suffix.lower()
        language = EXTENSION_LANGUAGES.get(extension)
        if language:
            languages[language] += 1
        top_level[path.parts[0] if path.parts else relative] += 1
        name = path.name
        if name in MANIFEST_SIGNALS:
            manifests.append({"path": relative, "signal": MANIFEST_SIGNALS[name]})
        if name in {"AGENTS.md", "CONTEXT.md", "CLAUDE.md"}:
            instruction_files.append(relative)
        normalized = relative.replace(os.sep, "/")
        if normalized.startswith(".github/workflows/") or normalized.startswith(".gitlab-ci"):
            ci_files.append(relative)
        lowered = normalized.lower()
        if any(token in lowered for token in ("/test/", "/tests/", "_test.", ".test.", ".spec.")):
            test_files += 1
        if extension in {".md", ".rst", ".adoc"}:
            doc_files += 1
        try:
            total_bytes += (root / relative).stat().st_size
        except OSError:
            pass

    status = _git_lines(root, ["status", "--porcelain=v1"], allow_failure=True)
    current_branch_result = run(["git", "branch", "--show-current"], cwd=root, check=False)
    worktree_records = _git_lines(root, ["worktree", "list", "--porcelain"], allow_failure=True)
    worktrees: list[dict[str, str]] = []
    current: dict[str, str] = {}
    for line in [*worktree_records, ""]:
        if not line:
            if current:
                worktrees.append(current)
                current = {}
            continue
        key, _, value = line.partition(" ")
        if key in {"worktree", "HEAD", "branch"}:
            current[key] = value

    architecture_signals: list[str] = []
    if len({item["path"].split("/", 1)[0] for item in manifests}) > 2:
        architecture_signals.append("multiple top-level manifest boundaries")
    if any(item["path"].startswith(("packages/", "apps/", "services/", "crates/")) for item in manifests):
        architecture_signals.append("workspace or monorepo-style package layout")
    if ci_files:
        architecture_signals.append("continuous-integration workflows present")
    if test_files:
        architecture_signals.append("dedicated test surfaces present")
    if any(item["signal"] in {"Container build", "Docker Compose stack", "Terraform infrastructure"} for item in manifests):
        architecture_signals.append("deployment or infrastructure surface present")

    return {
        "schema_version": 1,
        "project": {
            "root": str(root),
            "name": root.name,
            "current_branch": current_branch_result.stdout.strip() or None,
            "default_branch": _default_branch(root),
            "dirty": bool(status),
            "changed_entry_count": len(status),
        },
        "inventory": {
            "file_count": len(files),
            "approximate_bytes": total_bytes,
            "language_file_counts": dict(languages.most_common()),
            "top_level_entry_counts": dict(top_level.most_common(40)),
            "manifests": sorted(manifests, key=lambda item: item["path"]),
            "instruction_files": sorted(instruction_files),
            "ci_files": sorted(ci_files),
            "test_file_count": test_files,
            "documentation_file_count": doc_files,
        },
        "architecture_signals": architecture_signals,
        "existing_worktrees": worktrees,
        "constraints": {
            "preserve_dirty_tree": bool(status),
            "project_instructions_must_be_read": sorted(instruction_files),
        },
    }
