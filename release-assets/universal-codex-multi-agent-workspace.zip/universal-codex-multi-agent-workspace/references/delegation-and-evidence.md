# Delegation transport and behavioral evidence

Read this reference when running or diagnosing the required delegation smoke test.

## Transport requirement

Every task brief declares one of two requirements:

- `any-delegation`: a real persistent-thread dispatch is preferred; a real `spawn_agent` plus completed `wait_agent` handoff is an acceptable fallback.
- `persistent-thread`: the assignment must reach the exact recorded `thread_id` and complete through persistent-thread waiting. A spawned replacement does not satisfy this requirement.

If a `persistent-thread` task cannot access `send_message_to_thread` / `wait_threads`, return `PERSISTENT_THREAD_UNAVAILABLE`. Reserve `DELEGATION_UNAVAILABLE` for the case where neither persistent-thread messaging nor subagent collaboration can perform an `any-delegation` task.

## Completion evidence

Setup creates `.codex/multi-agent/smoke-test-template.json`. After a read-only smoke test involving at least two distinct specialists, copy its shape to `.codex/multi-agent/smoke-test.json` and replace every placeholder with observed evidence.

- A persistent-thread assignment records the exact target thread, dispatch/message ID, final completion ID, and final wait cursor.
- A subagent assignment records the child agent ID, dispatch ID, and completion ID.
- A readiness acknowledgement, commentary message, created worktree, or initialized thread is never a completion ID.
- Set `waited_for_all` and `final_check_after_all` only after every required handoff is complete.
- Set `main_performed_specialist_work` and `unauthorized_writes` from observed behavior, not intention.

Validate the record with:

```text
python3 <skill-dir>/scripts/validate_smoke.py --project-root <git-root>
```

A transport-specific test can fail while the portable `any-delegation` path passes. Report both results; never relabel a spawned child as the requested persistent thread.
