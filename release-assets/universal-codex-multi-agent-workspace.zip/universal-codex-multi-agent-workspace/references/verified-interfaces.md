# Verified interfaces (2026-08-27)

Primary sources used for the baseline:

- OpenAI Codex Skill format and locations: https://learn.chatgpt.com/docs/build-skills
- OpenAI Codex app-server lifecycle and methods: https://learn.chatgpt.com/docs/app-server
- OpenAI Codex custom agents and per-agent model/reasoning settings: https://learn.chatgpt.com/docs/agent-configuration/subagents
- OpenAI Codex worktrees: https://learn.chatgpt.com/docs/environments/git-worktrees
- CodexMonitor current README and Tauri surface: https://github.com/Dimillian/CodexMonitor/blob/main/README.md
- CodexMonitor daemon protocol note: https://github.com/Dimillian/CodexMonitor/blob/main/REMOTE_BACKEND_POC.md
- CodexMonitor current source tree: https://github.com/Dimillian/CodexMonitor/tree/main/src-tauri/src/bin/codex_monitor_daemon

Local source verification used commit `dd61b9abd37de5ded86e82b9fe8a83fd49d46fa5`, whose Tauri config reports version `0.7.68`.

Reality boundary:

- `SKILL.md`, project-scoped `.codex/agents/*.toml`, Git worktrees, and Codex app-server are official Codex mechanisms.
- CodexMonitor's daemon and Tauri commands are implemented in current source.
- The daemon's `REMOTE_BACKEND_POC.md` title and some prose are stale relative to the current README and connected remote mode. The protocol is therefore treated as capability-probed and version-adaptive, not as a permanent SDK contract.
- Tauri commands require the app's invoke bridge; they are not exposed as a general standalone IPC endpoint.
- Local behavioral testing on 2026-08-27 exposed app-level peer-thread messaging/waiting to the top-level Orchestrator, while a delegated Main task did not receive those tools. The delegated Main successfully used Codex subagent spawn/wait instead. Treat tool visibility as context-dependent and capability-probe it every run.
- A successful spawned subagent proves portable delegation, but it does not prove delivery to a requested existing sidebar thread. Keep those acceptance claims separate in task briefs and smoke evidence.
