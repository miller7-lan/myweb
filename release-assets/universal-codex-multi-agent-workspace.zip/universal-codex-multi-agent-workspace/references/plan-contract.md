# Team plan contract

The canonical schema is `config/team-plan.schema.json`; `config/team-plan.example.json` is a shape example, not a recommended fixed roster.

Important invariants enforced beyond JSON Schema:

- `version` is `1`.
- `project.root` resolves to the target Git root.
- Agent IDs, names, branches, and profile filenames are unique.
- Exactly one agent has `kind: "main"`; it does not use a worktree.
- The main agent is a delegation-only Orchestrator. Its responsibilities must cover decomposition, dispatch, handoff validation, integration, and final acceptance; do not assign it a solver or routine implementation mission.
- A writing specialist uses a worktree. A shared specialist must be read-only.
- Dependency IDs exist and form no cycle.
- Exclusive ownership cannot contain an identical or clearly nested literal path claimed by another exclusive owner.
- Model and effort are non-empty. `"auto"` is allowed only as a runtime fallback.

The provisioner normalizes the plan into `.codex/multi-agent/team.json` and generates profiles. Do not hand-write generated `.toml` files after provisioning; change the plan and re-run.

For execution, Main creates one task brief per specialist assignment from `.codex/multi-agent/task-template.md` and stores it in `.codex/multi-agent/tasks/`. Every brief declares `any-delegation` or `persistent-thread`. A task is delegated only after the permitted transport succeeds and a final handoff arrives. A spawned replacement cannot satisfy `persistent-thread`. Merely listing, creating, or initializing a worker is not delegation.
