from __future__ import annotations

import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL_ROOT / "scripts"))

from ucmaw.discovery import discover_project


class DiscoveryTests(unittest.TestCase):
    def test_discovers_project_signals_without_mutating_repo(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            subprocess.run(["git", "init", "-q", str(root)], check=True)
            (root / "package.json").write_text('{"name":"fixture"}\n', encoding="utf-8")
            (root / "src").mkdir()
            (root / "src" / "index.ts").write_text("export const answer = 42;\n", encoding="utf-8")
            (root / "AGENTS.md").write_text("# Instructions\n", encoding="utf-8")
            before = subprocess.run(["git", "status", "--porcelain"], cwd=root, text=True, stdout=subprocess.PIPE, check=True).stdout
            result = discover_project(root)
            after = subprocess.run(["git", "status", "--porcelain"], cwd=root, text=True, stdout=subprocess.PIPE, check=True).stdout
            self.assertEqual(before, after)
            self.assertEqual(result["project"]["root"], str(root.resolve()))
            self.assertEqual(result["inventory"]["language_file_counts"]["TypeScript"], 1)
            self.assertIn("AGENTS.md", result["inventory"]["instruction_files"])


if __name__ == "__main__":
    unittest.main()
