from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL_ROOT / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from test_plan import valid_plan
from test_evidence import two_specialist_plan, valid_evidence
from ucmaw.common import UcmawError
from ucmaw.orchestrator import provision


def initialize_repo(root: Path) -> None:
    subprocess.run(["git", "init", "-q", str(root)], check=True)
    (root / "README.md").write_text("fixture\n", encoding="utf-8")
    (root / "src" / "lane").mkdir(parents=True)
    (root / "src" / "lane" / "module.txt").write_text("fixture\n", encoding="utf-8")
    subprocess.run(["git", "add", "."], cwd=root, check=True)
    subprocess.run(
        ["git", "-c", "user.name=Fixture", "-c", "user.email=fixture@example.invalid", "commit", "-qm", "initial"],
        cwd=root,
        check=True,
    )


class ProvisionTests(unittest.TestCase):
    def test_no_thread_provisioning_is_idempotent(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "repo"
            root.mkdir()
            initialize_repo(root)
            plan = valid_plan(str(root.resolve()))
            plan_path = root.parent / "plan.json"
            plan_path.write_text(json.dumps(plan), encoding="utf-8")
            first = provision(plan_path, root, backend="none")
            second = provision(plan_path, root, backend="none")
            self.assertEqual(first["status"], "complete")
            self.assertTrue(first["agents"]["owned_lane"]["created_worktree"])
            self.assertFalse(second["agents"]["owned_lane"]["created_worktree"])
            records = subprocess.run(
                ["git", "worktree", "list", "--porcelain"],
                cwd=root,
                text=True,
                stdout=subprocess.PIPE,
                check=True,
            ).stdout
            self.assertEqual(records.count("branch refs/heads/codex/agent/owned-lane"), 1)
            self.assertTrue((root / ".codex" / "agents" / "owned_lane.toml").exists())
            self.assertTrue((root / ".codex" / "multi-agent" / "task-template.md").exists())
            self.assertTrue((root / ".codex" / "multi-agent" / "smoke-test-template.json").exists())
            self.assertTrue((root / ".codex" / "multi-agent" / "tasks").is_dir())

            main_profile = (root / ".codex" / "agents" / "main.toml").read_text(encoding="utf-8")
            self.assertIn("send_message_to_thread", main_profile)
            self.assertIn("wait_threads", main_profile)
            self.assertIn("DELEGATION_UNAVAILABLE", main_profile)

    def test_refuses_unmanaged_profile_collision(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "repo"
            root.mkdir()
            initialize_repo(root)
            plan = valid_plan(str(root.resolve()))
            plan_path = root.parent / "plan.json"
            plan_path.write_text(json.dumps(plan), encoding="utf-8")
            profile = root / ".codex" / "agents" / "main.toml"
            profile.parent.mkdir(parents=True)
            profile.write_text('name = "existing"\n', encoding="utf-8")
            with self.assertRaises(UcmawError):
                provision(plan_path, root, backend="none")

    def test_provisioned_workspace_passes_required_smoke_self_check(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "repo"
            root.mkdir()
            initialize_repo(root)
            plan = two_specialist_plan(str(root.resolve()))
            plan_path = root.parent / "plan.json"
            plan_path.write_text(json.dumps(plan), encoding="utf-8")
            provision(plan_path, root, backend="none")

            tasks = root / ".codex" / "multi-agent" / "tasks"
            (tasks / "smoke-owned.md").write_text("owned\n", encoding="utf-8")
            (tasks / "smoke-review.md").write_text("review\n", encoding="utf-8")
            evidence = valid_evidence(plan)
            evidence["assignments"][0].update(
                {
                    "transport": "subagent",
                    "target_thread_id": None,
                    "child_agent_id": "child-owned",
                    "wait_cursor": None,
                }
            )
            smoke_path = root / ".codex" / "multi-agent" / "smoke-test.json"
            smoke_path.write_text(json.dumps(evidence), encoding="utf-8")

            completed = subprocess.run(
                [
                    sys.executable,
                    str(SKILL_ROOT / "scripts" / "self_check.py"),
                    "--project-root",
                    str(root),
                    "--require-smoke",
                ],
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=False,
            )
            self.assertEqual(completed.returncode, 0, completed.stderr or completed.stdout)
            self.assertIn('"status": "pass"', completed.stdout)


if __name__ == "__main__":
    unittest.main()
