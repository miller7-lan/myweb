from __future__ import annotations

import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL_ROOT / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from test_plan import valid_plan
from ucmaw.evidence import validate_smoke_evidence
from ucmaw.plan import plan_digest


def two_specialist_plan(root: str) -> dict:
    plan = valid_plan(root)
    second = copy.deepcopy(plan["agents"][1])
    second.update({"id": "review_lane", "name": "Review Lane", "branch": None, "writes": False, "worktree": False})
    second["ownership"] = {"include": ["**/*"], "exclude": [], "exclusive": False}
    plan["agents"].append(second)
    plan["orchestration"]["max_parallel"] = 3
    plan["orchestration"]["integration_order"].append("review_lane")
    return plan


def valid_evidence(plan: dict) -> dict:
    return {
        "managed_by": "universal-codex-multi-agent-workspace",
        "version": 1,
        "plan_digest": plan_digest(plan),
        "requested_transport": "any-delegation",
        "assignments": [
            {
                "task_id": "smoke-owned",
                "agent_id": "owned_lane",
                "brief_path": ".codex/multi-agent/tasks/smoke-owned.md",
                "transport": "persistent-thread",
                "target_thread_id": "thread-1",
                "child_agent_id": None,
                "dispatch_id": "message-1",
                "completion_id": "final-1",
                "wait_cursor": "cursor-1",
                "handoff_status": "completed",
            },
            {
                "task_id": "smoke-review",
                "agent_id": "review_lane",
                "brief_path": ".codex/multi-agent/tasks/smoke-review.md",
                "transport": "subagent",
                "target_thread_id": None,
                "child_agent_id": "child-1",
                "dispatch_id": "spawn-1",
                "completion_id": "finish-1",
                "wait_cursor": None,
                "handoff_status": "completed",
            },
        ],
        "waited_for_all": True,
        "final_check_after_all": True,
        "main_performed_specialist_work": False,
        "unauthorized_writes": False,
        "status": "pass",
    }


class SmokeEvidenceTests(unittest.TestCase):
    def test_accepts_mixed_transport_for_any_delegation(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            tasks = root / ".codex" / "multi-agent" / "tasks"
            tasks.mkdir(parents=True)
            (tasks / "smoke-owned.md").write_text("owned\n", encoding="utf-8")
            (tasks / "smoke-review.md").write_text("review\n", encoding="utf-8")
            plan = two_specialist_plan(str(root))
            self.assertEqual(
                validate_smoke_evidence(valid_evidence(plan), plan, plan_digest(plan), project_root=root),
                [],
            )

    def test_rejects_spawned_substitute_for_persistent_requirement(self) -> None:
        plan = two_specialist_plan("/tmp/example")
        evidence = valid_evidence(plan)
        evidence["requested_transport"] = "persistent-thread"
        errors = validate_smoke_evidence(evidence, plan, plan_digest(plan))
        self.assertTrue(any("did not use the required persistent-thread transport" in error for error in errors))

    def test_rejects_readiness_and_early_final_check(self) -> None:
        plan = two_specialist_plan("/tmp/example")
        evidence = valid_evidence(plan)
        evidence["assignments"][0]["handoff_status"] = "ready"
        evidence["assignments"][0]["completion_id"] = ""
        evidence["final_check_after_all"] = False
        errors = validate_smoke_evidence(evidence, plan, plan_digest(plan))
        self.assertTrue(any("handoff_status must be completed" in error for error in errors))
        self.assertTrue(any("completion_id must be a non-empty string" in error for error in errors))
        self.assertIn("final_check_after_all must be true", errors)

    def test_validate_smoke_cli_accepts_complete_project_evidence(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "repo"
            root.mkdir()
            subprocess.run(["git", "init", "-q", str(root)], check=True)
            tasks = root / ".codex" / "multi-agent" / "tasks"
            tasks.mkdir(parents=True)
            (tasks / "smoke-owned.md").write_text("owned\n", encoding="utf-8")
            (tasks / "smoke-review.md").write_text("review\n", encoding="utf-8")
            plan = two_specialist_plan(str(root.resolve()))
            plan_hash = plan_digest(plan)
            team = {
                "managed_by": "universal-codex-multi-agent-workspace",
                "plan_digest": plan_hash,
                "plan": plan,
            }
            (tasks.parent / "team.json").write_text(json.dumps(team), encoding="utf-8")
            (tasks.parent / "smoke-test.json").write_text(json.dumps(valid_evidence(plan)), encoding="utf-8")
            state = {
                "managed_by": "universal-codex-multi-agent-workspace",
                "agents": {
                    "owned_lane": {"thread_id": "thread-1"},
                    "review_lane": {"thread_id": None},
                },
            }
            (tasks.parent / "state.json").write_text(json.dumps(state), encoding="utf-8")

            completed = subprocess.run(
                [sys.executable, str(SKILL_ROOT / "scripts" / "validate_smoke.py"), "--project-root", str(root)],
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=False,
            )
            self.assertEqual(completed.returncode, 0, completed.stderr or completed.stdout)
            self.assertIn('"status": "pass"', completed.stdout)

    def test_rejects_persistent_thread_not_recorded_in_state(self) -> None:
        plan = two_specialist_plan("/tmp/example")
        evidence = valid_evidence(plan)
        state = {"agents": {"owned_lane": {"thread_id": "different-thread"}}}
        errors = validate_smoke_evidence(evidence, plan, plan_digest(plan), state=state)
        self.assertTrue(any("does not match state.json" in error for error in errors))


if __name__ == "__main__":
    unittest.main()
