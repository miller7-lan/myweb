---
name: universal-codex-multi-agent-workspace
description: Discover any Git project, design a project-specific Orchestrator plus specialist Codex team, and idempotently provision enforced delegation rules, project-scoped custom agents, worktrees, and initialized CodexMonitor or app-server threads. Use when the user wants a reusable multi-agent workspace or automatic Codex team setup; do not use for ordinary one-agent coding tasks.
---

# Universal Codex Multi-Agent Workspace

Provision a team that fits the repository instead of selecting agents from a fixed catalog. Keep the workflow local-first, capability-driven, non-destructive, and repeatable.

## Required workflow

1. Resolve the Git root. Read applicable `AGENTS.md` files and inspect the repository without changing it.
2. Run:

   ```text
   python3 <skill-dir>/scripts/discover_project.py --project-root <git-root> --output <temporary-discovery.json>
   python3 <skill-dir>/scripts/probe_runtime.py --project-root <git-root> --output <temporary-runtime.json>
   ```

   These commands are read-only. Never expose daemon tokens from their output or subsequent reports.
3. Read [team design](references/team-design.md), then design the smallest useful team. Always include exactly one delegation-only Orchestrator; never combine it with a solver or routine implementer role. Derive specialists from the actual architecture, risks, task boundaries, and validation needs. Do not assume mathematics, frontend/backend, security, or any other fixed agent type.
4. Choose each agent's exact `model` and `effort` from the runtime catalog when available. Record why the routing fits that agent. Do not assume model names are stable. If no catalog is available, use `"auto"`; the provisioner will resolve the runtime default and record the fallback.
5. Create a plan from [config/team-plan.example.json](config/team-plan.example.json), validate it, and provision it:

   ```text
   python3 <skill-dir>/scripts/validate_plan.py --plan <plan.json>
   python3 <skill-dir>/scripts/provision_workspace.py --plan <plan.json> --project-root <git-root>
   ```

6. Read the provisioner's JSON report. Run `scripts/self_check.py` against the project. Fix safe, in-scope failures and re-run; do not delete, reset, overwrite unmanaged files, or push/merge automatically.
7. Read [delegation transport and evidence](references/delegation-and-evidence.md), then run a harmless read-only smoke test through the initialized Orchestrator. Give at least two relevant specialists distinct `any-delegation` task briefs, verify that Main actually dispatches, waits for every final handoff, and synthesizes only afterward. If the user specifically requires existing persistent threads, run a separate `persistent-thread` test and do not count spawned substitutes as success.
8. Save observed evidence as `.codex/multi-agent/smoke-test.json`, then run:

   ```text
   python3 <skill-dir>/scripts/validate_smoke.py --project-root <git-root>
   python3 <skill-dir>/scripts/self_check.py --project-root <git-root> --require-smoke
   ```

9. Report the generated team, ownership, worktrees, thread IDs, resolved model/effort pairs, backend used, portable delegation result, persistent-thread result when requested, validated smoke evidence, and any fallback.

## Provisioning invariants

- Prefer a capability-probed CodexMonitor daemon. Reuse matching workspace, worktree, and named thread records.
- Otherwise use the installed official `codex app-server` protocol. Its persisted threads are discoverable by clients that list threads for the same `cwd`.
- Treat the CodexMonitor Tauri command surface as an internal app interface, not a directly callable public SDK.
- Use Computer Use only after both machine-readable routes are unavailable or incompatible. If the `computer-use:computer-use` skill is installed, load it immediately before operating the CodexMonitor UI. Reuse visible workspaces/threads and verify every created item. Never use UI automation to bypass an approval or security boundary.
- Pass the selected model and reasoning effort on every initialization turn. UI dropdown persistence is not proof of runtime routing.
- Create project-scoped profiles under `.codex/agents/`; never change user-global Codex defaults.
- A persistent sidebar task, worktree, or initialized specialist thread is only a worker endpoint. It is not a child of Main and is not evidence that Main delegated work.
- For every substantive task matching a specialist responsibility, Main must create a task brief under `.codex/multi-agent/tasks/` and actually send it using available Codex subagent collaboration or the recorded persistent thread ID. If neither transport exists, Main must return `DELEGATION_UNAVAILABLE` and stop instead of doing the specialist work itself.
- Every task brief declares `any-delegation` or `persistent-thread`. A spawned substitute is acceptable only for `any-delegation`; if the exact persistent thread is required but peer-thread tools are unavailable, return `PERSISTENT_THREAD_UNAVAILABLE`.
- Use one dedicated Git worktree per specialist unless the plan explicitly marks the agent read-only and shared. Main remains in the original checkout by default.
- Preserve dirty working trees. Never stash, reset, checkout over changes, delete branches/worktrees, commit, push, merge, or modify `.gitignore` automatically.
- Write only managed files under `.codex/multi-agent/` and new, non-conflicting `.codex/agents/*.toml`. Refuse to overwrite an unmanaged custom-agent file.
- A repeated run with an unchanged plan must reuse resources and avoid duplicate initialization turns.

## Capability and error handling

Read [backend routing](references/backend-routing.md) only when selecting or diagnosing a backend. Read [plan contract](references/plan-contract.md) when creating or repairing a plan.

Stop and ask for direction only when a real conflict remains, such as an existing branch checked out elsewhere, an unmanaged profile collision, missing Git repository, unavailable authentication, or a non-loopback daemon that was not explicitly allowed. Do not broaden filesystem or network permissions to make setup succeed.

## Completion standard

Setup is complete only when:

- the plan validates;
- managed team/protocol/profile files exist and match the plan digest;
- every writing specialist has a distinct worktree and branch;
- each initialized thread maps to the intended workspace path;
- the runtime accepted or explicitly resolved every model/effort pair;
- the self-check reports no errors;
- `validate_smoke.py` accepts the behavioral evidence;
- a behavioral smoke test proves that Main created distinct briefs, dispatched them through the permitted transport, waited, and synthesized the returned work without directly performing specialist-owned execution.
