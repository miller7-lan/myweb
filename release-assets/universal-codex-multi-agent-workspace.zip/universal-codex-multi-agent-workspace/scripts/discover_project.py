#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from ucmaw.common import UcmawError, write_output
from ucmaw.discovery import discover_project


def main() -> int:
    parser = argparse.ArgumentParser(description="Read-only Git project discovery for dynamic agent-team design")
    parser.add_argument("--project-root", default=".", help="Any path inside the target Git repository")
    parser.add_argument("--output", help="Optional JSON output path")
    args = parser.parse_args()
    try:
        write_output(discover_project(args.project_root), args.output)
        return 0
    except UcmawError as exc:
        write_output({"status": "error", "error": str(exc)}, args.output)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
