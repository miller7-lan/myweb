# TASK <unique-task-id>

## TARGET AGENT
<agent-id>

## TRANSPORT REQUIREMENT
<any-delegation or persistent-thread>

## TARGET PERSISTENT THREAD
<exact thread-id or none>

## OBJECTIVE
<one bounded outcome>

## INPUTS
- <authoritative file, artifact, or fact>

## DEPENDENCIES
- <completed upstream task or none>

## METHOD BOUNDARY
- <required definitions and allowed choices>

## CONSTRAINTS
- Stay within the target agent profile and ownership boundary.
- Preserve unrelated and pre-existing changes.

## EXPECTED OUTPUT
- <file, report, result, commit, or structured handoff>

## ACCEPTANCE CRITERIA
- <observable criterion>

## VALIDATION
- <command or check>

## FILES ALLOWED TO MODIFY
- <path or none>

## STOP CONDITIONS
- Stop and return a scoped blocker if <condition>.
- For `persistent-thread`, return `PERSISTENT_THREAD_UNAVAILABLE` rather than substituting a spawned agent.
