from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .common import (
    MANAGED_BY,
    UcmawError,
    atomic_write_json,
    atomic_write_text,
    canonical_path,
    digest,
    ensure_managed_target,
    load_json,
    resolve_git_root,
    run,
)
from .plan import (
    agent_profile_hash,
    initialization_prompt,
    load_and_validate_plan,
    plan_digest,
    render_agent_toml,
    render_protocol,
)
from .rpc import (
    AppServerClient,
    DaemonRpcClient,
    RpcError,
    codexmonitor_workspace_registry,
    discover_daemon_target,
    extract_model_catalog,
    extract_thread_id,
    extract_turn_id,
    is_loopback_endpoint,
    resolve_model_effort,
    start_configured_daemon,
)


SKILL_ROOT = Path(__file__).resolve().parents[2]


def load_defaults() -> dict[str, Any]:
    defaults = load_json(SKILL_ROOT / "config" / "defaults.json")
    if not isinstance(defaults, dict):
        raise UcmawError("Skill defaults.json is missing or invalid")
    return defaults


def _managed_paths(root: Path, defaults: dict[str, Any]) -> dict[str, Path]:
    state_dir = root / defaults["state_directory"]
    return {
        "state_dir": state_dir,
        "team": state_dir / "team.json",
        "protocol": state_dir / "protocol.md",
        "task_template": state_dir / "task-template.md",
        "smoke_template": state_dir / "smoke-test-template.json",
        "tasks": state_dir / "tasks",
        "state": state_dir / "state.json",
        "report": state_dir / "last-report.json",
        "profiles": root / defaults["agent_profile_directory"],
    }


def _state(root: Path, defaults: dict[str, Any]) -> dict[str, Any]:
    state_path = _managed_paths(root, defaults)["state"]
    value = load_json(state_path, default={})
    if not isinstance(value, dict) or value.get("managed_by") not in (None, MANAGED_BY):
        raise UcmawError(f"Refusing to use unmanaged state file: {state_path}")
    value.setdefault("managed_by", MANAGED_BY)
    value.setdefault("version", 1)
    value.setdefault("agents", {})
    return value


def _write_artifacts(
    root: Path,
    defaults: dict[str, Any],
    plan: dict[str, Any],
    plan_hash: str,
    routing: dict[str, tuple[str, str]] | None = None,
) -> dict[str, str]:
    paths = _managed_paths(root, defaults)
    paths["state_dir"].mkdir(parents=True, exist_ok=True)
    paths["tasks"].mkdir(parents=True, exist_ok=True)
    paths["profiles"].mkdir(parents=True, exist_ok=True)
    template = (SKILL_ROOT / "assets" / "templates" / "protocol.md.tpl").read_text(encoding="utf-8")
    task_template = (SKILL_ROOT / "assets" / "templates" / "task-brief.md.tpl").read_text(encoding="utf-8")
    smoke_template = (SKILL_ROOT / "assets" / "templates" / "smoke-evidence.json.tpl").read_text(encoding="utf-8")
    wrapper = {"managed_by": MANAGED_BY, "plan_digest": plan_hash, "plan": plan}
    atomic_write_json(paths["team"], wrapper)
    atomic_write_text(paths["protocol"], render_protocol(plan, plan_hash, template))
    atomic_write_text(paths["task_template"], task_template)
    atomic_write_text(paths["smoke_template"], smoke_template.replace("{{PLAN_DIGEST}}", plan_hash))
    written: dict[str, str] = {
        "team": str(paths["team"]),
        "protocol": str(paths["protocol"]),
        "task_template": str(paths["task_template"]),
        "smoke_template": str(paths["smoke_template"]),
        "tasks": str(paths["tasks"]),
    }
    for agent in plan["agents"]:
        profile = paths["profiles"] / f"{agent['id']}.toml"
        ensure_managed_target(profile)
        pair = routing.get(agent["id"]) if routing else None
        atomic_write_text(
            profile,
            render_agent_toml(
                agent,
                plan,
                plan_hash,
                model=pair[0] if pair else None,
                effort=pair[1] if pair else None,
            ),
        )
        written[f"profile:{agent['id']}"] = str(profile)
    return written


def _sync_artifacts_to_worktree(
    root: Path,
    worktree: Path,
    defaults: dict[str, Any],
    plan: dict[str, Any],
    plan_hash: str,
    routing: dict[str, tuple[str, str]],
) -> None:
    if canonical_path(root) == canonical_path(worktree):
        return
    source_paths = _managed_paths(root, defaults)
    destination_paths = _managed_paths(worktree, defaults)
    destination_paths["state_dir"].mkdir(parents=True, exist_ok=True)
    destination_paths["tasks"].mkdir(parents=True, exist_ok=True)
    destination_paths["profiles"].mkdir(parents=True, exist_ok=True)
    atomic_write_text(destination_paths["protocol"], source_paths["protocol"].read_text(encoding="utf-8"))
    atomic_write_text(destination_paths["team"], source_paths["team"].read_text(encoding="utf-8"))
    atomic_write_text(destination_paths["task_template"], source_paths["task_template"].read_text(encoding="utf-8"))
    atomic_write_text(destination_paths["smoke_template"], source_paths["smoke_template"].read_text(encoding="utf-8"))
    for agent in plan["agents"]:
        destination = destination_paths["profiles"] / f"{agent['id']}.toml"
        ensure_managed_target(destination)
        model, effort = routing[agent["id"]]
        atomic_write_text(destination, render_agent_toml(agent, plan, plan_hash, model, effort))


def _parse_worktrees(root: Path) -> list[dict[str, str]]:
    result = run(["git", "worktree", "list", "--porcelain"], cwd=root)
    records: list[dict[str, str]] = []
    current: dict[str, str] = {}
    for line in [*result.stdout.splitlines(), ""]:
        if not line:
            if current:
                records.append(current)
                current = {}
            continue
        key, _, value = line.partition(" ")
        if key in {"worktree", "HEAD", "branch"}:
            current[key] = value
    return records


def _local_worktree_path(root: Path, agent_id: str) -> Path:
    suffix = digest(canonical_path(root))[:10]
    return root.parent / ".codex-multi-agent-worktrees" / f"{root.name}-{suffix}" / agent_id


def _ensure_local_worktree(root: Path, agent: dict[str, Any], previous: dict[str, Any] | None) -> tuple[Path, bool]:
    if not agent["worktree"]:
        return root, False
    branch = agent["branch"]
    assert isinstance(branch, str)
    check_ref = run(["git", "check-ref-format", "--branch", branch], cwd=root, check=False)
    if check_ref.returncode != 0:
        raise UcmawError(f"Invalid worktree branch for {agent['id']}: {branch}")
    records = _parse_worktrees(root)
    branch_ref = f"refs/heads/{branch}"
    existing = next((record for record in records if record.get("branch") == branch_ref), None)
    desired = Path(previous.get("path")) if previous and previous.get("path") else _local_worktree_path(root, agent["id"])
    desired = desired.expanduser().resolve()
    if existing:
        existing_path = Path(existing["worktree"]).resolve()
        if canonical_path(existing_path) != canonical_path(desired):
            raise UcmawError(
                f"Branch {branch} is already checked out at unmanaged/different path {existing_path}; "
                f"expected {desired}"
            )
        return existing_path, False
    if desired.exists():
        raise UcmawError(f"Refusing to overwrite unregistered worktree directory: {desired}")
    desired.parent.mkdir(parents=True, exist_ok=True)
    branch_exists = run(["git", "show-ref", "--verify", "--quiet", branch_ref], cwd=root, check=False).returncode == 0
    if branch_exists:
        run(["git", "worktree", "add", str(desired), branch], cwd=root, timeout=120)
    else:
        run(["git", "worktree", "add", "-b", branch, str(desired)], cwd=root, timeout=120)
    return desired, True


def _workspace_for_path(workspaces: list[dict[str, Any]], path: Path | str) -> dict[str, Any] | None:
    target = canonical_path(path)
    return next(
        (
            workspace
            for workspace in workspaces
            if isinstance(workspace, dict)
            and isinstance(workspace.get("path"), str)
            and canonical_path(workspace["path"]) == target
        ),
        None,
    )


def _daemon_thread_by_name(client: DaemonRpcClient, workspace_id: str, name: str) -> str | None:
    cursor: str | None = None
    for _ in range(10):
        result = client.call(
            "list_threads",
            {"workspaceId": workspace_id, "cursor": cursor, "limit": 100, "sortKey": "updated_at"},
        )
        if not isinstance(result, dict):
            return None
        for thread in result.get("data", []):
            if isinstance(thread, dict) and thread.get("name") == name and isinstance(thread.get("id"), str):
                return thread["id"]
        cursor = result.get("nextCursor")
        if not cursor:
            break
    return None


def _thread_name(agent: dict[str, Any]) -> str:
    return f"UCMAW / {agent['name']} [{agent['id']}]"


def _ensure_daemon_workspace(client: DaemonRpcClient, root: Path) -> tuple[dict[str, Any], bool]:
    listed = client.call("list_workspaces", {})
    workspaces = listed if isinstance(listed, list) else []
    workspace = _workspace_for_path(workspaces, root)
    if workspace:
        client.call("connect_workspace", {"id": workspace["id"]})
        return workspace, False
    workspace = client.call("add_workspace", {"path": str(root)})
    if not isinstance(workspace, dict) or not workspace.get("id"):
        raise RpcError("CodexMonitor add_workspace returned an invalid workspace")
    client.call("connect_workspace", {"id": workspace["id"]})
    return workspace, True


def _provision_daemon(
    root: Path,
    defaults: dict[str, Any],
    plan: dict[str, Any],
    plan_hash: str,
    state: dict[str, Any],
    allow_remote_daemon: bool,
    force_init: bool,
    report: dict[str, Any],
) -> tuple[bool, bool]:
    target = discover_daemon_target(defaults["daemon"]["default_host"])
    report["backend_attempts"].append({"backend": "codexmonitor-daemon", "target": target.public()})
    if not is_loopback_endpoint(target.host) and not allow_remote_daemon:
        report["warnings"].append("Skipped non-loopback CodexMonitor daemon; explicit opt-in is required")
        return False, False
    mutated = False
    try:
        daemon_start = start_configured_daemon(target)
        report["backend_attempts"][-1]["daemon_start"] = daemon_start
        with DaemonRpcClient(target, timeout=float(defaults["daemon"]["timeout_seconds"])) as client:
            client.call("ping", {})
            try:
                daemon_info = client.call("daemon_info", {})
            except RpcError:
                daemon_info = {"version": "unknown"}
            report["runtime"]["codexmonitor_daemon"] = daemon_info
            main_workspace, created = _ensure_daemon_workspace(client, root)
            mutated = mutated or created
            model_result = client.call("model_list", {"workspaceId": main_workspace["id"]})
            catalog = extract_model_catalog(model_result)
            if not catalog:
                raise RpcError("CodexMonitor model_list returned an empty catalog")
            try:
                skills_result = client.call("skills_list", {"workspaceId": main_workspace["id"]})
                report["runtime"]["skills_list_available"] = skills_result is not None
            except RpcError as exc:
                report["warnings"].append(str(exc))
                report["runtime"]["skills_list_available"] = False

            routing: dict[str, tuple[str, str]] = {}
            for agent in plan["agents"]:
                model, effort, warnings = resolve_model_effort(agent["model"], agent["effort"], catalog)
                routing[agent["id"]] = (model, effort)
                report["warnings"].extend(f"{agent['id']}: {warning}" for warning in warnings)
            _write_artifacts(root, defaults, plan, plan_hash, routing)

            workspaces = client.call("list_workspaces", {})
            workspaces = workspaces if isinstance(workspaces, list) else []
            agent_state = state.setdefault("agents", {})
            for agent in plan["agents"]:
                previous = agent_state.get(agent["id"], {}) if isinstance(agent_state.get(agent["id"]), dict) else {}
                workspace = main_workspace
                created_worktree = False
                if agent["worktree"]:
                    workspace = next(
                        (
                            item
                            for item in workspaces
                            if isinstance(item, dict)
                            and item.get("parentId") == main_workspace["id"]
                            and isinstance(item.get("worktree"), dict)
                            and item["worktree"].get("branch") == agent["branch"]
                        ),
                        None,
                    )
                    if workspace is None:
                        workspace = client.call(
                            "add_worktree",
                            {
                                "parentId": main_workspace["id"],
                                "branch": agent["branch"],
                                "name": agent["name"],
                                "copyAgentsMd": True,
                            },
                        )
                        mutated = True
                        created_worktree = True
                        if not isinstance(workspace, dict) or not workspace.get("id"):
                            raise RpcError(f"CodexMonitor add_worktree returned invalid data for {agent['id']}")
                        workspaces.append(workspace)
                    client.call("connect_workspace", {"id": workspace["id"]})
                workspace_path = Path(workspace["path"]).resolve()
                _sync_artifacts_to_worktree(root, workspace_path, defaults, plan, plan_hash, routing)
                model, effort = routing[agent["id"]]
                profile_hash = digest({"profile": agent_profile_hash(agent, plan_hash), "model": model, "effort": effort})
                thread_id: str | None = None
                if previous.get("backend") == "codexmonitor-daemon" and previous.get("thread_id"):
                    try:
                        client.call(
                            "resume_thread",
                            {"workspaceId": workspace["id"], "threadId": previous["thread_id"]},
                        )
                        thread_id = previous["thread_id"]
                    except RpcError:
                        thread_id = None
                if thread_id is None:
                    thread_id = _daemon_thread_by_name(client, workspace["id"], _thread_name(agent))
                    if thread_id:
                        client.call("resume_thread", {"workspaceId": workspace["id"], "threadId": thread_id})
                new_thread = False
                if thread_id is None:
                    thread_result = client.call("start_thread", {"workspaceId": workspace["id"]})
                    thread_id = extract_thread_id(thread_result)
                    if not thread_id:
                        raise RpcError(f"CodexMonitor start_thread returned no thread ID for {agent['id']}")
                    client.call(
                        "set_thread_name",
                        {"workspaceId": workspace["id"], "threadId": thread_id, "name": _thread_name(agent)},
                    )
                    mutated = True
                    new_thread = True
                should_initialize = force_init or new_thread or previous.get("profile_hash") != profile_hash
                turn_id = previous.get("turn_id")
                if should_initialize:
                    turn_result = client.call(
                        "send_user_message",
                        {
                            "workspaceId": workspace["id"],
                            "threadId": thread_id,
                            "text": initialization_prompt(agent, plan, plan_hash),
                            "model": model,
                            "effort": effort,
                            "accessMode": defaults["initialization"]["access_mode"],
                            "images": [],
                        },
                    )
                    turn_id = extract_turn_id(turn_result)
                    mutated = True
                agent_state[agent["id"]] = {
                    "backend": "codexmonitor-daemon",
                    "workspace_id": workspace["id"],
                    "path": str(workspace_path),
                    "branch": agent["branch"],
                    "thread_id": thread_id,
                    "turn_id": turn_id,
                    "profile_hash": profile_hash,
                    "model": model,
                    "effort": effort,
                    "created_worktree": created_worktree,
                    "initialization_sent": should_initialize,
                }
                report["agents"][agent["id"]] = dict(agent_state[agent["id"]])
            state["backend"] = "codexmonitor-daemon"
            state["plan_digest"] = plan_hash
            state["project_root"] = str(root)
            report["backend"] = "codexmonitor-daemon"
            return True, mutated
    except (RpcError, OSError) as exc:
        report["backend_attempts"][-1]["error"] = str(exc)
        return False, mutated


def _provision_app_server(
    root: Path,
    defaults: dict[str, Any],
    plan: dict[str, Any],
    plan_hash: str,
    state: dict[str, Any],
    force_init: bool,
    report: dict[str, Any],
) -> bool:
    report["backend_attempts"].append({"backend": "codex-app-server"})
    mutated = False
    try:
        with AppServerClient(timeout=float(defaults["app_server"]["request_timeout_seconds"])) as client:
            catalog = client.models()
            if not catalog:
                raise RpcError("codex app-server returned an empty model catalog")
            try:
                skills_result = client.skills(root)
                report["runtime"]["skills_list_available"] = skills_result is not None
            except RpcError as exc:
                report["warnings"].append(str(exc))
                report["runtime"]["skills_list_available"] = False
            routing: dict[str, tuple[str, str]] = {}
            for agent in plan["agents"]:
                model, effort, warnings = resolve_model_effort(agent["model"], agent["effort"], catalog)
                routing[agent["id"]] = (model, effort)
                report["warnings"].extend(f"{agent['id']}: {warning}" for warning in warnings)
            _write_artifacts(root, defaults, plan, plan_hash, routing)
            agent_state = state.setdefault("agents", {})
            for agent in plan["agents"]:
                previous = agent_state.get(agent["id"], {}) if isinstance(agent_state.get(agent["id"]), dict) else {}
                previous_for_worktree = previous if previous.get("backend") == "codex-app-server" else None
                workspace_path, created_worktree = _ensure_local_worktree(root, agent, previous_for_worktree)
                mutated = mutated or created_worktree
                _sync_artifacts_to_worktree(root, workspace_path, defaults, plan, plan_hash, routing)
                model, effort = routing[agent["id"]]
                profile_hash = digest({"profile": agent_profile_hash(agent, plan_hash), "model": model, "effort": effort})
                thread_id: str | None = None
                if previous.get("backend") == "codex-app-server" and previous.get("thread_id"):
                    try:
                        client.resume_thread(previous["thread_id"])
                        thread_id = previous["thread_id"]
                    except RpcError:
                        thread_id = None
                new_thread = False
                if thread_id is None:
                    thread_id = client.start_thread(workspace_path, model)
                    client.set_thread_name(thread_id, _thread_name(agent))
                    new_thread = True
                    mutated = True
                should_initialize = force_init or new_thread or previous.get("profile_hash") != profile_hash
                turn_id = previous.get("turn_id")
                if should_initialize:
                    turn_id = client.initialize_turn(
                        thread_id,
                        workspace_path,
                        initialization_prompt(agent, plan, plan_hash),
                        model,
                        effort,
                        timeout=float(defaults["app_server"]["initialization_timeout_seconds"]),
                    )
                    mutated = True
                agent_state[agent["id"]] = {
                    "backend": "codex-app-server",
                    "workspace_id": None,
                    "path": str(workspace_path),
                    "branch": agent["branch"],
                    "thread_id": thread_id,
                    "turn_id": turn_id,
                    "profile_hash": profile_hash,
                    "model": model,
                    "effort": effort,
                    "created_worktree": created_worktree,
                    "initialization_sent": should_initialize,
                }
                report["agents"][agent["id"]] = dict(agent_state[agent["id"]])
            state["backend"] = "codex-app-server"
            state["plan_digest"] = plan_hash
            state["project_root"] = str(root)
            report["backend"] = "codex-app-server"
            registry = codexmonitor_workspace_registry(
                [entry["path"] for entry in agent_state.values() if isinstance(entry, dict) and entry.get("path")]
            )
            report["codexmonitor_registration"] = registry
            if not registry["all_registered"]:
                report["computer_use_fallback_required"] = True
                report["warnings"].append(
                    "app-server threads and Git worktrees are ready, but not every path is registered in a local "
                    "CodexMonitor workspace registry; use the final Computer Use fallback to add or verify them"
                )
            return True
    except (RpcError, UcmawError, OSError) as exc:
        report["backend_attempts"][-1]["error"] = str(exc)
        if mutated:
            report["errors"].append(
                "app-server provisioning stopped after safe partial changes; re-run after resolving: " + str(exc)
            )
        return False


def _provision_without_threads(
    root: Path,
    defaults: dict[str, Any],
    plan: dict[str, Any],
    plan_hash: str,
    state: dict[str, Any],
    report: dict[str, Any],
) -> None:
    routing = {agent["id"]: (agent["model"], agent["effort"]) for agent in plan["agents"]}
    _write_artifacts(root, defaults, plan, plan_hash, routing)
    for agent in plan["agents"]:
        previous = state.get("agents", {}).get(agent["id"], {})
        workspace_path, created = _ensure_local_worktree(root, agent, previous if isinstance(previous, dict) else None)
        _sync_artifacts_to_worktree(root, workspace_path, defaults, plan, plan_hash, routing)
        report["agents"][agent["id"]] = {
            "backend": "none",
            "path": str(workspace_path),
            "branch": agent["branch"],
            "created_worktree": created,
            "model": agent["model"],
            "effort": agent["effort"],
            "thread_id": None,
            "initialization_sent": False,
        }
    state.update({"backend": "none", "plan_digest": plan_hash, "project_root": str(root), "agents": report["agents"]})
    report["backend"] = "none"


def provision(
    plan_path: Path | str,
    project_root: Path | str | None = None,
    *,
    backend: str = "auto",
    allow_remote_daemon: bool = False,
    force_init: bool = False,
    no_threads: bool = False,
    dry_run: bool = False,
) -> dict[str, Any]:
    defaults = load_defaults()
    raw_plan = load_json(plan_path)
    declared_root = raw_plan.get("project", {}).get("root") if isinstance(raw_plan, dict) else None
    root = resolve_git_root(project_root or declared_root or Path.cwd())
    plan = load_and_validate_plan(plan_path, project_root=root, max_agents=int(defaults["max_agents"]))
    plan_hash = plan_digest(plan)
    report: dict[str, Any] = {
        "managed_by": MANAGED_BY,
        "version": 1,
        "status": "planned" if dry_run else "running",
        "project_root": str(root),
        "plan_digest": plan_hash,
        "backend": None,
        "backend_attempts": [],
        "runtime": {},
        "agents": {},
        "warnings": [],
        "errors": [],
        "computer_use_fallback_required": False,
    }
    if dry_run:
        for agent in plan["agents"]:
            report["agents"][agent["id"]] = {
                "planned_path": str(_local_worktree_path(root, agent["id"])) if agent["worktree"] else str(root),
                "branch": agent["branch"],
                "model": agent["model"],
                "effort": agent["effort"],
            }
        return report

    _write_artifacts(root, defaults, plan, plan_hash)
    state = _state(root, defaults)
    success = False
    if no_threads or backend == "none":
        _provision_without_threads(root, defaults, plan, plan_hash, state, report)
        success = True
    else:
        if backend in {"auto", "daemon"}:
            success, daemon_mutated = _provision_daemon(
                root,
                defaults,
                plan,
                plan_hash,
                state,
                allow_remote_daemon,
                force_init,
                report,
            )
            if not success and daemon_mutated:
                report["errors"].append(
                    "CodexMonitor daemon provisioning made safe partial changes before failing; fix the reported issue and re-run"
                )
        if not success and backend in {"auto", "app-server"} and not report["errors"]:
            success = _provision_app_server(root, defaults, plan, plan_hash, state, force_init, report)
        if not success and not report["errors"]:
            report["computer_use_fallback_required"] = True
            report["warnings"].append(
                "Both programmatic backends are unavailable or incompatible; the invoking agent may use Computer Use as the final fallback"
            )

    state_path = _managed_paths(root, defaults)["state"]
    state["last_status"] = "complete" if success and not report["computer_use_fallback_required"] else "partial"
    atomic_write_json(state_path, state)
    report["state_file"] = str(state_path)
    report["status"] = (
        "partial"
        if report["errors"]
        else "needs_computer_use"
        if report["computer_use_fallback_required"]
        else "complete"
        if success
        else "partial"
    )
    atomic_write_json(_managed_paths(root, defaults)["report"], report)
    return report
