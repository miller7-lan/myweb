# Universal Codex Multi-Agent Workspace

A local-first Codex Skill that discovers a Git repository, designs a project-specific delegation-only Orchestrator + specialist team, generates project-scoped custom-agent profiles and coordination rules, creates or reuses Git worktrees, and initializes Codex threads through a verified CodexMonitor daemon or the official Codex app-server.

It intentionally does **not** ship a fixed roster. The invoking Codex instance derives the team from the repository and validates its plan before any setup mutation.

## Install

Personal installation (available in every project):

```bash
mkdir -p "$HOME/.codex/skills"
cp -R universal-codex-multi-agent-workspace "$HOME/.codex/skills/"
```

Repository-scoped installation (commit it with one project):

```bash
mkdir -p .agents/skills
cp -R universal-codex-multi-agent-workspace .agents/skills/
```

Codex detects skill changes automatically. Restart Codex only if it does not appear.

## Use

From any directory inside a Git repository:

```text
$universal-codex-multi-agent-workspace set up the best multi-agent workspace for this project
```

The normal path requires no manual prompt copying, worktree creation, agent profile editing, or CodexMonitor setup. Codex performs discovery, writes a validated team plan, provisions resources, initializes the threads, runs a read-only delegation smoke test, and returns a report.

The Skill distinguishes worker setup from actual delegation. Seeing specialist tasks in the sidebar only proves that endpoints exist. For each real task, the Orchestrator must create a task brief, send it through subagent collaboration or persistent-thread messaging, wait for the return, validate it, and then synthesize. If no dispatch transport exists, it stops with `DELEGATION_UNAVAILABLE` instead of doing the specialist work itself.

Task briefs distinguish portable `any-delegation` from `persistent-thread`. The former may fall back to a real spawned subagent; the latter must reach the exact recorded thread and returns `PERSISTENT_THREAD_UNAVAILABLE` when the active Orchestrator cannot access peer-thread tools. Validated smoke evidence prevents the two outcomes from being reported as the same success.

## What it writes to the target project

- `.codex/multi-agent/team.json`: normalized team plan.
- `.codex/multi-agent/protocol.md`: task, ownership, handoff, Git, and integration rules.
- `.codex/multi-agent/task-template.md`: required task-brief structure.
- `.codex/multi-agent/smoke-test-template.json`: evidence shape for a behavioral delegation test.
- `.codex/multi-agent/smoke-test.json`: observed dispatch/wait evidence after a completed smoke test.
- `.codex/multi-agent/tasks/`: auditable task briefs created before dispatch.
- `.codex/multi-agent/state.json`: reusable workspace/worktree/thread identifiers and plan hashes.
- `.codex/multi-agent/last-report.json`: latest machine-readable result.
- `.codex/agents/<agent-id>.toml`: official project-scoped Codex custom-agent profiles.

The provisioner does not edit `AGENTS.md`, `.gitignore`, user-global configuration, commits, remotes, or existing unmanaged agent profiles.

## Backend order

1. A reachable, authenticated CodexMonitor daemon whose capabilities pass runtime probes.
2. The installed official `codex app-server` over stdio.
3. Codex Computer Use against the CodexMonitor UI, only when the two programmatic routes are unavailable.

CodexMonitor credentials are taken from explicit environment variables or an existing local CodexMonitor settings file and are never printed. Non-loopback daemon connections require explicit opt-in.

Useful environment overrides:

```bash
export CODEX_MONITOR_DAEMON_HOST="127.0.0.1:4732"
export CODEX_MONITOR_DAEMON_TOKEN="..."
```

## Direct script checks

The Skill normally runs these for you:

```bash
python3 scripts/discover_project.py --project-root /path/to/repo
python3 scripts/probe_runtime.py --project-root /path/to/repo
python3 scripts/validate_plan.py --plan /path/to/team-plan.json
python3 scripts/provision_workspace.py --plan /path/to/team-plan.json --project-root /path/to/repo
python3 scripts/validate_smoke.py --project-root /path/to/repo
python3 scripts/self_check.py --project-root /path/to/repo --require-smoke
python3 -m unittest discover -s tests -v
```

Python 3.10+ and Git are required. There are no third-party Python dependencies.

## Verified interface baseline

The implementation is capability-driven, but its baseline was checked on 2026-08-27 against:

- OpenAI's current Codex Skill format (`SKILL.md`, optional scripts/references/assets and `agents/openai.yaml`).
- The official Codex app-server lifecycle and `thread/start`, `turn/start`, `model/list`, and `skills/list` methods.
- `Dimillian/CodexMonitor` `main` commit `dd61b9abd37de5ded86e82b9fe8a83fd49d46fa5` (Tauri config version `0.7.68`), including daemon RPC routing for workspaces, worktrees, threads, models, skills, and per-turn model/effort.

See `references/verified-interfaces.md` for source links and the stability boundary.
