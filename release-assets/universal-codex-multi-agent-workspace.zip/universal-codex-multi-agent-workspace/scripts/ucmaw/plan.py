from __future__ import annotations

import json
import re
from pathlib import Path, PurePosixPath
from typing import Any

from .common import MANAGED_HEADER, UcmawError, canonical_path, digest, resolve_git_root


ID_RE = re.compile(r"^[a-z][a-z0-9_-]{0,47}$")
REQUIRED_AGENT_FIELDS = {
    "id", "name", "kind", "role", "mission", "responsibilities", "ownership",
    "writes", "worktree", "branch", "model", "effort", "routing_reason",
    "depends_on", "quality_gates",
}


def _nonempty_string(value: Any, label: str, errors: list[str]) -> None:
    if not isinstance(value, str) or not value.strip():
        errors.append(f"{label} must be a non-empty string")


def _literal_prefix(pattern: str) -> str | None:
    normalized = pattern.replace("\\", "/").strip().lstrip("./")
    if not normalized or any(char in normalized for char in "*?[]{}!"):
        return None
    try:
        parts = PurePosixPath(normalized).parts
    except ValueError:
        return None
    if ".." in parts:
        return None
    return "/".join(parts).rstrip("/")


def _has_dependency_cycle(agents: list[dict[str, Any]]) -> bool:
    graph = {agent["id"]: list(agent.get("depends_on", [])) for agent in agents}
    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(node: str) -> bool:
        if node in visiting:
            return True
        if node in visited:
            return False
        visiting.add(node)
        if any(dependency in graph and visit(dependency) for dependency in graph.get(node, [])):
            return True
        visiting.remove(node)
        visited.add(node)
        return False

    return any(visit(node) for node in graph)


def validate_plan(plan: Any, project_root: Path | str | None = None, max_agents: int = 12) -> list[str]:
    errors: list[str] = []
    if not isinstance(plan, dict):
        return ["plan must be a JSON object"]
    if plan.get("version") != 1:
        errors.append("version must be 1")
    project = plan.get("project")
    if not isinstance(project, dict):
        errors.append("project must be an object")
        project = {}
    for field in ("root", "name", "objective"):
        _nonempty_string(project.get(field), f"project.{field}", errors)

    agents = plan.get("agents")
    if not isinstance(agents, list) or not agents:
        errors.append("agents must be a non-empty array")
        return errors
    if len(agents) > max_agents:
        errors.append(f"agents exceeds configured maximum ({max_agents})")

    ids: list[str] = []
    names: list[str] = []
    branches: list[str] = []
    main_count = 0
    for index, agent in enumerate(agents):
        label = f"agents[{index}]"
        if not isinstance(agent, dict):
            errors.append(f"{label} must be an object")
            continue
        missing = REQUIRED_AGENT_FIELDS - set(agent)
        if missing:
            errors.append(f"{label} is missing fields: {', '.join(sorted(missing))}")
        agent_id = agent.get("id")
        if not isinstance(agent_id, str) or not ID_RE.fullmatch(agent_id):
            errors.append(f"{label}.id must match {ID_RE.pattern}")
        else:
            ids.append(agent_id)
        _nonempty_string(agent.get("name"), f"{label}.name", errors)
        if isinstance(agent.get("name"), str):
            names.append(agent["name"].casefold())
        if agent.get("kind") not in {"main", "specialist"}:
            errors.append(f"{label}.kind must be main or specialist")
        if agent.get("kind") == "main":
            main_count += 1
            if agent.get("worktree") is not False:
                errors.append(f"{label}: Main must use the original checkout")
        for field in ("role", "mission", "model", "effort", "routing_reason"):
            _nonempty_string(agent.get(field), f"{label}.{field}", errors)
        for field in ("responsibilities", "depends_on", "quality_gates"):
            value = agent.get(field)
            if not isinstance(value, list):
                errors.append(f"{label}.{field} must be an array")
        if isinstance(agent.get("responsibilities"), list) and not agent["responsibilities"]:
            errors.append(f"{label}.responsibilities must not be empty")
        if not isinstance(agent.get("writes"), bool) or not isinstance(agent.get("worktree"), bool):
            errors.append(f"{label}.writes and worktree must be booleans")
        if agent.get("kind") == "specialist" and agent.get("writes") and not agent.get("worktree"):
            errors.append(f"{label}: writing specialists require a worktree")
        if agent.get("kind") == "specialist" and not agent.get("writes") and not agent.get("worktree"):
            pass
        branch = agent.get("branch")
        if agent.get("worktree"):
            _nonempty_string(branch, f"{label}.branch", errors)
            if isinstance(branch, str):
                branches.append(branch)
        elif branch is not None:
            errors.append(f"{label}.branch must be null when worktree is false")
        ownership = agent.get("ownership")
        if not isinstance(ownership, dict):
            errors.append(f"{label}.ownership must be an object")
        else:
            include = ownership.get("include")
            exclude = ownership.get("exclude")
            if not isinstance(include, list) or not include:
                errors.append(f"{label}.ownership.include must be a non-empty array")
            if not isinstance(exclude, list):
                errors.append(f"{label}.ownership.exclude must be an array")
            if not isinstance(ownership.get("exclusive"), bool):
                errors.append(f"{label}.ownership.exclusive must be boolean")
            for pattern in [*(include or []), *(exclude or [])]:
                if not isinstance(pattern, str) or not pattern.strip():
                    errors.append(f"{label}.ownership patterns must be non-empty strings")
                elif ".." in PurePosixPath(pattern.replace("\\", "/")).parts:
                    errors.append(f"{label}.ownership pattern escapes the project: {pattern}")

    if main_count != 1:
        errors.append("exactly one agent must have kind=main")
    if len(ids) != len(set(ids)):
        errors.append("agent IDs must be unique")
    if len(names) != len(set(names)):
        errors.append("agent names must be unique")
    if len(branches) != len(set(branches)):
        errors.append("worktree branches must be unique")

    id_set = set(ids)
    for agent in agents:
        if not isinstance(agent, dict):
            continue
        for dependency in agent.get("depends_on", []) if isinstance(agent.get("depends_on"), list) else []:
            if dependency not in id_set:
                errors.append(f"agent {agent.get('id')} depends on unknown agent {dependency}")
            if dependency == agent.get("id"):
                errors.append(f"agent {dependency} cannot depend on itself")
    if not errors and _has_dependency_cycle(agents):
        errors.append("agent dependencies contain a cycle")

    exclusive_literals: list[tuple[str, str]] = []
    for agent in agents:
        if not isinstance(agent, dict) or agent.get("kind") == "main":
            continue
        ownership = agent.get("ownership", {})
        if not isinstance(ownership, dict) or not ownership.get("exclusive"):
            continue
        for pattern in ownership.get("include", []):
            literal = _literal_prefix(pattern)
            if literal:
                exclusive_literals.append((agent.get("id", "?"), literal))
    for left_index, (left_id, left_path) in enumerate(exclusive_literals):
        for right_id, right_path in exclusive_literals[left_index + 1 :]:
            if left_id == right_id:
                continue
            if left_path == right_path or left_path.startswith(right_path + "/") or right_path.startswith(left_path + "/"):
                errors.append(f"exclusive ownership overlaps: {left_id}:{left_path} and {right_id}:{right_path}")

    orchestration = plan.get("orchestration")
    if not isinstance(orchestration, dict):
        errors.append("orchestration must be an object")
    else:
        max_parallel = orchestration.get("max_parallel")
        if not isinstance(max_parallel, int) or not 1 <= max_parallel <= max(1, len(agents)):
            errors.append("orchestration.max_parallel must be between 1 and the team size")
        order = orchestration.get("integration_order")
        if not isinstance(order, list):
            errors.append("orchestration.integration_order must be an array")
        else:
            unknown = [item for item in order if item not in id_set]
            if unknown:
                errors.append(f"integration_order contains unknown agents: {', '.join(unknown)}")
        if not isinstance(orchestration.get("shared_quality_gates"), list):
            errors.append("orchestration.shared_quality_gates must be an array")

    if project_root is not None and project.get("root"):
        try:
            actual = resolve_git_root(project_root)
            declared = resolve_git_root(project["root"])
            if canonical_path(actual) != canonical_path(declared):
                errors.append(f"project.root does not match target Git root: {declared} != {actual}")
        except UcmawError as exc:
            errors.append(str(exc))
    return errors


def load_and_validate_plan(path: Path | str, project_root: Path | str | None = None, max_agents: int = 12) -> dict[str, Any]:
    try:
        plan = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise UcmawError(f"Could not read team plan {path}: {exc}") from exc
    errors = validate_plan(plan, project_root=project_root, max_agents=max_agents)
    if errors:
        raise UcmawError("Invalid team plan:\n- " + "\n- ".join(errors))
    return plan


def plan_digest(plan: dict[str, Any]) -> str:
    return digest(plan)


def agent_profile_hash(agent: dict[str, Any], plan_hash: str) -> str:
    return digest({"agent": agent, "plan_digest": plan_hash})


def _toml_string(value: str) -> str:
    return json.dumps(value, ensure_ascii=False)


def main_delegation_contract(plan: dict[str, Any]) -> str:
    specialists = [agent for agent in plan["agents"] if agent["kind"] == "specialist"]
    roster = "\n".join(
        f"- {agent['id']}: {agent['name']} — {agent['role']}"
        for agent in specialists
    ) or "- none"
    return (
        "MANDATORY DELEGATION GATE\n"
        "You are the delegation-only Orchestrator. You are not a Solver and must not originate specialist work.\n"
        "For every substantive task covered by an available specialist, delegation is mandatory even if direct execution would be faster.\n\n"
        f"Available specialists:\n{roster}\n\n"
        "DIRECT DISPATCH PROCEDURE\n"
        "1. Decompose the user request and select every relevant specialist. Preserve dependency order.\n"
        "2. Create one complete Markdown brief per assignment from .codex/multi-agent/task-template.md and save it under .codex/multi-agent/tasks/.\n"
        "3. Set TRANSPORT REQUIREMENT in each brief. Use any-delegation for portable specialist work; use persistent-thread only when the exact recorded worker thread is itself part of the requirement.\n"
        "4. Read .codex/multi-agent/state.json immediately before dispatch to resolve each specialist's current thread_id, model, effort, and workspace path.\n"
        "5. When send_message_to_thread and wait_threads are available, send the full brief body to each recorded specialist thread. Do not send only a path. Pass the recorded model and effort when the tool supports them.\n"
        "6. Wait with wait_threads until every dispatched thread completes or needs attention. Track returned cursors, do not treat commentary or readiness acknowledgements as completion, and continue waiting on unfinished threads.\n"
        "7. For any-delegation only, if persistent-thread tools are unavailable, call spawn_agent for the matching project-scoped custom agent, send follow-ups when needed, and wait with wait_agent. For persistent-thread, return PERSISTENT_THREAD_UNAVAILABLE; a spawned replacement is not success.\n"
        "8. Inspect every final handoff against its brief. Request bounded rework when necessary. Perform the final cross-agent correctness check only after all required handoffs arrive.\n"
        "9. For a smoke test, record observed dispatch and completion IDs in .codex/multi-agent/smoke-test.json and validate it with scripts/validate_smoke.py.\n"
        "10. Synthesize and communicate the accepted result.\n\n"
        "A sidebar task, worktree, profile, initialized thread, or readiness acknowledgement is not delegation. Successful message dispatch plus a completed handoff is delegation evidence.\n"
        "Main may directly edit only task briefs, shared specifications, decision records, integration/conflict resolutions, and final acceptance records. It must not directly implement code, create plots, draft specialist paper sections, or perform independent review work assigned to a specialist.\n"
        "If neither persistent-thread messaging nor subagent collaboration is available for an any-delegation task, return DELEGATION_UNAVAILABLE with the missing capability and stop. Do not silently fall back to single-agent execution."
    )


def agent_instructions(agent: dict[str, Any], plan: dict[str, Any]) -> str:
    ownership = agent["ownership"]
    include = ", ".join(ownership["include"])
    exclude = ", ".join(ownership["exclude"]) or "none"
    responsibilities = "\n".join(f"- {item}" for item in agent["responsibilities"])
    gates = "\n".join(f"- {item}" for item in agent["quality_gates"]) or "- Follow project validation"
    common = (
        f"You are {agent['name']}, the {agent['role']} for {plan['project']['name']}.\n\n"
        f"Mission: {agent['mission']}\n\nResponsibilities:\n{responsibilities}\n\n"
        f"Ownership include: {include}\nOwnership exclude: {exclude}\n"
        f"Exclusive ownership: {str(ownership['exclusive']).lower()}\n\n"
    )
    if agent["kind"] == "main":
        return common + main_delegation_contract(plan) + f"\n\nQuality gates:\n{gates}"
    return (
        common
        + "Follow .codex/multi-agent/protocol.md. Accept work only from a complete task brief sent by Main. "
        "Stay within assigned ownership, preserve unrelated changes, and return a structured handoff to Main. "
        "Do not commit, push, merge, reset, stash, delete branches, or edit another worktree unless explicitly instructed.\n\n"
        + f"Quality gates:\n{gates}"
    )


def render_agent_toml(agent: dict[str, Any], plan: dict[str, Any], plan_hash: str, model: str | None = None, effort: str | None = None) -> str:
    selected_model = model or agent["model"]
    selected_effort = effort or agent["effort"]
    sandbox = "workspace-write" if agent["writes"] else "read-only"
    lines = [
        f"# {MANAGED_HEADER}",
        f"# Plan digest: {plan_hash}",
        f"name = {_toml_string(agent['id'])}",
        f"description = {_toml_string(agent['role'])}",
    ]
    if selected_model != "auto":
        lines.append(f"model = {_toml_string(selected_model)}")
    if selected_effort != "auto":
        lines.append(f"model_reasoning_effort = {_toml_string(selected_effort)}")
    lines.extend(
        [
            f"sandbox_mode = {_toml_string(sandbox)}",
            f"developer_instructions = {_toml_string(agent_instructions(agent, plan))}",
            "",
        ]
    )
    return "\n".join(lines)


def render_protocol(plan: dict[str, Any], plan_hash: str, template: str) -> str:
    table = ["| Agent | Kind | Writes | Worktree | Ownership | Model / effort |", "|---|---|---:|---:|---|---|"]
    for agent in plan["agents"]:
        owned = "<br>".join(agent["ownership"]["include"])
        table.append(
            f"| {agent['name']} (`{agent['id']}`) | {agent['kind']} | {str(agent['writes']).lower()} | "
            f"{str(agent['worktree']).lower()} | {owned} | `{agent['model']}` / `{agent['effort']}` |"
        )
    order = plan["orchestration"]["integration_order"]
    integration = "\n".join(f"{index}. `{agent_id}`" for index, agent_id in enumerate(order, start=1)) or "1. Main integrates directly."
    gates = "\n".join(f"- {gate}" for gate in plan["orchestration"]["shared_quality_gates"]) or "- Project validation passes."
    return (
        template.replace("{{PROJECT_NAME}}", plan["project"]["name"])
        .replace("{{PLAN_DIGEST}}", plan_hash)
        .replace("{{TEAM_TABLE}}", "\n".join(table))
        .replace("{{INTEGRATION_ORDER}}", integration)
        .replace("{{SHARED_GATES}}", gates)
    )


def initialization_prompt(agent: dict[str, Any], plan: dict[str, Any], plan_hash: str) -> str:
    roster = ", ".join(f"{item['name']} ({item['id']})" for item in plan["agents"])
    dependencies = ", ".join(agent["depends_on"]) or "none"
    common = (
        f"Initialize as {agent['name']} (`{agent['id']}`), {agent['role']}, for {plan['project']['name']}.\n"
        f"Plan digest: {plan_hash}. Mission: {agent['mission']}\n"
        f"Ownership: {', '.join(agent['ownership']['include'])}; exclusions: {', '.join(agent['ownership']['exclude']) or 'none'}.\n"
        f"Dependencies: {dependencies}. Team: {roster}.\n"
    )
    if agent["kind"] == "main":
        return (
            common
            + "Read your project-scoped profile, .codex/multi-agent/protocol.md, and .codex/multi-agent/state.json before future work.\n\n"
            + main_delegation_contract(plan)
            + "\n\nFor this initialization turn only, do not run tools or change files. Reply with a concise readiness acknowledgement that confirms you will use direct thread dispatch plus waiting when available."
        )
    return (
        common
        + "Read the project-scoped custom-agent profile and .codex/multi-agent/protocol.md when handling future tasks. "
        "For this initialization turn, do not run tools or change files. Reply only with a concise readiness acknowledgement "
        "that includes your agent ID and ownership boundary."
    )
