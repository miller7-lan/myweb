from __future__ import annotations

import copy
import sys
import unittest
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL_ROOT / "scripts"))

from ucmaw.plan import (
    initialization_prompt,
    main_delegation_contract,
    render_agent_toml,
    render_protocol,
    validate_plan,
)


def valid_plan(root: str = "/tmp/example") -> dict:
    return {
        "version": 1,
        "project": {"root": root, "name": "example", "objective": "Parallel owned work"},
        "agents": [
            {
                "id": "main",
                "name": "Example Main",
                "kind": "main",
                "role": "Orchestrator",
                "mission": "Coordinate and validate",
                "responsibilities": ["Decompose tasks"],
                "ownership": {"include": ["**/*"], "exclude": [], "exclusive": False},
                "writes": True,
                "worktree": False,
                "branch": None,
                "model": "runtime-default",
                "effort": "medium",
                "routing_reason": "Integration reasoning",
                "depends_on": [],
                "quality_gates": ["Tests pass"],
            },
            {
                "id": "owned_lane",
                "name": "Owned Lane",
                "kind": "specialist",
                "role": "Derived owner",
                "mission": "Own one repository lane",
                "responsibilities": ["Implement the owned lane"],
                "ownership": {"include": ["src/lane"], "exclude": [], "exclusive": True},
                "writes": True,
                "worktree": True,
                "branch": "codex/agent/owned-lane",
                "model": "runtime-default",
                "effort": "medium",
                "routing_reason": "Ordinary implementation",
                "depends_on": [],
                "quality_gates": ["Lane tests pass"],
            },
        ],
        "orchestration": {
            "max_parallel": 2,
            "integration_order": ["owned_lane"],
            "shared_quality_gates": ["No conflicts"],
        },
    }


class PlanValidationTests(unittest.TestCase):
    def test_valid_shape_without_filesystem_validation(self) -> None:
        self.assertEqual(validate_plan(valid_plan(), project_root=None), [])

    def test_rejects_overlapping_exclusive_ownership(self) -> None:
        plan = valid_plan()
        second = copy.deepcopy(plan["agents"][1])
        second.update({"id": "nested_lane", "name": "Nested Lane", "branch": "codex/agent/nested"})
        second["ownership"]["include"] = ["src/lane/nested"]
        plan["agents"].append(second)
        plan["orchestration"]["max_parallel"] = 3
        errors = validate_plan(plan, project_root=None)
        self.assertTrue(any("exclusive ownership overlaps" in error for error in errors))

    def test_rejects_dependency_cycle(self) -> None:
        plan = valid_plan()
        plan["agents"][0]["depends_on"] = ["owned_lane"]
        plan["agents"][1]["depends_on"] = ["main"]
        errors = validate_plan(plan, project_root=None)
        self.assertIn("agent dependencies contain a cycle", errors)

    def test_profile_uses_official_custom_agent_fields(self) -> None:
        plan = valid_plan()
        rendered = render_agent_toml(plan["agents"][1], plan, "abc", "catalog-model", "high")
        self.assertIn('name = "owned_lane"', rendered)
        self.assertIn('model = "catalog-model"', rendered)
        self.assertIn('model_reasoning_effort = "high"', rendered)
        self.assertIn('sandbox_mode = "workspace-write"', rendered)
        self.assertIn("developer_instructions = ", rendered)

    def test_main_profile_requires_real_dispatch_and_wait(self) -> None:
        plan = valid_plan()
        contract = main_delegation_contract(plan)
        profile = render_agent_toml(plan["agents"][0], plan, "abc")

        for required in (
            "owned_lane",
            ".codex/multi-agent/tasks/",
            ".codex/multi-agent/state.json",
            "send_message_to_thread",
            "wait_threads",
            "spawn_agent",
            "wait_agent",
            "PERSISTENT_THREAD_UNAVAILABLE",
            "DELEGATION_UNAVAILABLE",
        ):
            self.assertIn(required, contract)
            self.assertIn(required, profile)

        self.assertIn("must not originate specialist work", contract)
        self.assertIn("only after all required handoffs arrive", contract)
        self.assertIn("a spawned replacement is not success", contract)

    def test_main_initialization_exposes_direct_thread_transport(self) -> None:
        plan = valid_plan()
        prompt = initialization_prompt(plan["agents"][0], plan, "abc")
        self.assertIn("send_message_to_thread", prompt)
        self.assertIn("wait_threads", prompt)
        self.assertIn("state.json", prompt)
        self.assertIn("do not run tools or change files", prompt)

    def test_protocol_distinguishes_worker_endpoint_from_delegation(self) -> None:
        plan = valid_plan()
        template = (SKILL_ROOT / "assets" / "templates" / "protocol.md.tpl").read_text(encoding="utf-8")
        protocol = render_protocol(plan, "abc", template)
        self.assertIn("A worktree, custom-agent profile, initialized thread", protocol)
        self.assertIn("send_message_to_thread", protocol)
        self.assertIn("wait_threads", protocol)
        self.assertIn("final cross-agent correctness check", protocol)
        self.assertIn("any-delegation", protocol)
        self.assertIn("PERSISTENT_THREAD_UNAVAILABLE", protocol)


if __name__ == "__main__":
    unittest.main()
