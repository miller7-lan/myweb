# TokenBar Windows

TokenBar 是 Windows 10/11 x64 托盘应用，用于查看本机 Codex JSONL Token 统计和当前 ChatGPT 套餐的 Codex 实时额度。

## 使用

1. 运行 `TokenBar.exe`，应用会驻留在系统托盘，不显示任务栏按钮。
2. 左键托盘图标打开面板；右键可切换统计、额度、设置、刷新或退出。
3. “今日 / 本周 / 本月”来自 `%USERPROFILE%\.codex\sessions` 中的本地会话记录。
4. “额度”通过本机已登录的 `codex app-server` 读取。需要先在 Codex 桌面应用或 CLI 登录，并保持联网。

应用不会读取或复制 `auth.json`、访问令牌或账号个人资料，也不提供购买 credits、消耗重置券或修改账户的操作。额度无法联网时会保留上次成功数据并标记可能已过期；本地 Token 统计仍可使用。

## 安装与数据

- MSI 为当前用户安装，默认位置：`%LOCALAPPDATA%\Programs\TokenBar`。
- 便携版无需安装 .NET，解压后直接运行 `TokenBar.exe`。
- 数据库和设置：`%LOCALAPPDATA%\TokenBar\usage.sqlite`。
- 默认开启开机启动，可在“设置”页关闭，也可添加其他 sessions 目录。
- 卸载不会删除数据库和设置。
- 当前安装包未签名，Windows SmartScreen 可能显示提醒。

## 构建

在 PowerShell 中运行：

```powershell
.\scripts\build-release.ps1
```

脚本会在项目内引导 .NET 10 SDK，运行测试，发布自包含 `win-x64` 程序，并在 `artifacts\release` 生成 MSI、便携 ZIP 和 SHA-256 校验文件。

额度通信基于官方 [Codex App Server 文档](https://learn.chatgpt.com/docs/app-server)，套餐说明参见 [Codex 定价和使用限制](https://learn.chatgpt.com/docs/pricing)。
