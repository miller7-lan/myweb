# Backend routing and stability boundary

## 1. CodexMonitor daemon

Probe first, mutate second. A usable daemon must authenticate (when configured), answer `ping`, provide `daemon_info` when supported, and implement the required methods. Reuse workspaces by canonical path, worktrees by parent ID + branch, and threads by managed state or the managed thread name.

The current daemon protocol is line-delimited JSON-RPC over TCP. It is real and implemented, but not a versioned public SDK. Do not trust a method list copied into this Skill: capability-probe every run and fall back on `unknown method`, incompatible payload, or schema mismatch.

Only auto-connect to loopback. A configured non-loopback endpoint requires `--allow-remote-daemon` or an equivalent explicit user instruction. Never print tokens or persist them in project files.

## 2. Official Codex app-server

Spawn `codex app-server --stdio`, perform `initialize`/`initialized`, then call the current protocol methods. Query `model/list` and `skills/list`; start or resume one persisted thread per agent; set its name; send an acknowledgement-only initialization turn with exact `model` and `effort` plus read-only sandboxing.

Persist thread IDs in managed project state. A later CodexMonitor/app client can list these sessions by matching `cwd`. If a stored thread cannot be resumed, create a replacement and record it.

The application-level `send_message_to_thread` / `wait_threads` tools may be exposed to the top-level app Orchestrator but not to a delegated Main task. Capability-check in the active Orchestrator context. For ordinary specialist work, use the official `spawn_agent` / `wait_agent` fallback when peer-thread tools are absent. For a task that explicitly requires an existing persistent thread, report `PERSISTENT_THREAD_UNAVAILABLE` instead of relabeling the fallback as success.

## 3. Computer Use

Use only when both programmatic routes fail. Load the installed Computer Use skill immediately before UI automation. Reuse visible items, create only missing items, set model/effort before each initialization send, and visually verify paths, branches, names, and resulting thread messages. Never interpret UI automation as permission to approve unrelated actions.

## Tauri IPC

CodexMonitor's Tauri `invoke` commands are a real internal surface used by its frontend, but a standalone Skill process cannot assume access to a running webview's invoke bridge. Do not claim it is a public external API or inject code into the app. Prefer the daemon or app-server.
