{
  "managed_by": "universal-codex-multi-agent-workspace",
  "version": 1,
  "plan_digest": "{{PLAN_DIGEST}}",
  "requested_transport": "any-delegation",
  "assignments": [
    {
      "task_id": "replace-task-1",
      "agent_id": "replace-specialist-1",
      "brief_path": ".codex/multi-agent/tasks/replace-task-1.md",
      "transport": "subagent",
      "target_thread_id": null,
      "child_agent_id": "replace-child-agent-id",
      "dispatch_id": "replace-dispatch-id",
      "completion_id": "replace-completion-id",
      "wait_cursor": null,
      "handoff_status": "completed"
    },
    {
      "task_id": "replace-task-2",
      "agent_id": "replace-specialist-2",
      "brief_path": ".codex/multi-agent/tasks/replace-task-2.md",
      "transport": "persistent-thread",
      "target_thread_id": "replace-thread-id",
      "child_agent_id": null,
      "dispatch_id": "replace-message-id",
      "completion_id": "replace-final-message-id",
      "wait_cursor": "replace-final-cursor",
      "handoff_status": "completed"
    }
  ],
  "waited_for_all": true,
  "final_check_after_all": true,
  "main_performed_specialist_work": false,
  "unauthorized_writes": false,
  "status": "pass"
}
