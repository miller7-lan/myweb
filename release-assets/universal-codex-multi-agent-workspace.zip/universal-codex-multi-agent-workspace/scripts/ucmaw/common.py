from __future__ import annotations

import hashlib
import json
import os
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Iterable


MANAGED_BY = "universal-codex-multi-agent-workspace"
MANAGED_HEADER = f"Managed by {MANAGED_BY}"


class UcmawError(RuntimeError):
    """Expected, user-actionable provisioning error."""


def run(
    args: Iterable[str],
    *,
    cwd: Path | str | None = None,
    check: bool = True,
    timeout: float = 30,
) -> subprocess.CompletedProcess[str]:
    command = [str(arg) for arg in args]
    try:
        completed = subprocess.run(
            command,
            cwd=str(cwd) if cwd is not None else None,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            check=False,
        )
    except FileNotFoundError as exc:
        raise UcmawError(f"Required command is unavailable: {command[0]}") from exc
    except subprocess.TimeoutExpired as exc:
        raise UcmawError(f"Command timed out: {' '.join(command)}") from exc
    if check and completed.returncode != 0:
        detail = completed.stderr.strip() or completed.stdout.strip() or "unknown error"
        raise UcmawError(f"Command failed ({' '.join(command)}): {detail}")
    return completed


def resolve_git_root(path: Path | str) -> Path:
    candidate = Path(path).expanduser().resolve()
    result = run(["git", "rev-parse", "--show-toplevel"], cwd=candidate)
    return Path(result.stdout.strip()).resolve()


def canonical_path(path: Path | str) -> str:
    return os.path.normcase(os.path.realpath(os.path.expanduser(str(path))))


def load_json(path: Path | str, default: Any = None) -> Any:
    target = Path(path)
    if not target.exists():
        return default
    try:
        return json.loads(target.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise UcmawError(f"Could not read JSON file {target}: {exc}") from exc


def stable_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def digest(value: Any) -> str:
    return hashlib.sha256(stable_json(value).encode("utf-8")).hexdigest()


def atomic_write_text(path: Path | str, content: str) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{target.name}.", dir=target.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
    finally:
        if temporary.exists():
            temporary.unlink()


def atomic_write_json(path: Path | str, value: Any) -> None:
    atomic_write_text(path, json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n")


def is_managed_text(path: Path | str) -> bool:
    target = Path(path)
    if not target.exists():
        return True
    try:
        prefix = target.read_text(encoding="utf-8")[:512]
    except OSError:
        return False
    return MANAGED_HEADER in prefix


def ensure_managed_target(path: Path | str) -> None:
    target = Path(path)
    if target.exists() and not is_managed_text(target):
        raise UcmawError(f"Refusing to overwrite unmanaged file: {target}")


def redact(value: Any) -> Any:
    secret_fragments = ("token", "secret", "password", "credential", "api_key", "apikey")
    if isinstance(value, dict):
        return {
            key: (
                redact(item)
                if isinstance(item, bool) and key.lower().endswith(("configured", "available"))
                else "<redacted>"
                if any(fragment in key.lower() for fragment in secret_fragments)
                else redact(item)
            )
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [redact(item) for item in value]
    return value


def write_output(value: Any, output: Path | str | None) -> None:
    rendered = json.dumps(redact(value), ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    if output:
        atomic_write_text(output, rendered)
    print(rendered, end="")
