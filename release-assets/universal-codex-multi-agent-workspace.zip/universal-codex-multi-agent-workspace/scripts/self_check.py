#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from ucmaw.common import MANAGED_BY, UcmawError, canonical_path, load_json, resolve_git_root, run, write_output
from ucmaw.evidence import validate_smoke_evidence
from ucmaw.orchestrator import load_defaults
from ucmaw.plan import plan_digest, validate_plan


def parse_worktrees(root: Path) -> dict[str, dict[str, str]]:
    result = run(["git", "worktree", "list", "--porcelain"], cwd=root)
    output: dict[str, dict[str, str]] = {}
    current: dict[str, str] = {}
    for line in [*result.stdout.splitlines(), ""]:
        if not line:
            if current.get("worktree"):
                output[canonical_path(current["worktree"])] = current
                current = {}
            continue
        key, _, value = line.partition(" ")
        if key in {"worktree", "HEAD", "branch"}:
            current[key] = value
    return output


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify a provisioned Universal Codex multi-agent workspace")
    parser.add_argument("--project-root", default=".")
    parser.add_argument("--require-smoke", action="store_true")
    parser.add_argument("--output")
    args = parser.parse_args()
    errors: list[str] = []
    warnings: list[str] = []
    try:
        root = resolve_git_root(args.project_root)
        defaults = load_defaults()
        state_dir = root / defaults["state_directory"]
        team_wrapper = load_json(state_dir / "team.json")
        state = load_json(state_dir / "state.json")
        if not isinstance(team_wrapper, dict) or team_wrapper.get("managed_by") != MANAGED_BY:
            errors.append("team.json is missing or unmanaged")
            plan = None
        else:
            plan = team_wrapper.get("plan")
            plan_errors = validate_plan(plan, project_root=root, max_agents=int(defaults["max_agents"]))
            errors.extend(f"plan: {item}" for item in plan_errors)
            if not plan_errors and team_wrapper.get("plan_digest") != plan_digest(plan):
                errors.append("team.json plan digest does not match its plan")
        if not (state_dir / "protocol.md").exists():
            errors.append("protocol.md is missing")
        if not (state_dir / "task-template.md").exists():
            errors.append("task-template.md is missing")
        if not (state_dir / "smoke-test-template.json").exists():
            errors.append("smoke-test-template.json is missing")
        if not (state_dir / "tasks").is_dir():
            errors.append("tasks directory is missing")
        if not isinstance(state, dict) or state.get("managed_by") != MANAGED_BY:
            errors.append("state.json is missing or unmanaged")
            state = {}
        elif team_wrapper and state.get("plan_digest") != team_wrapper.get("plan_digest"):
            errors.append("state.json plan digest does not match team.json")
        worktrees = parse_worktrees(root)
        if isinstance(plan, dict):
            smoke_path = state_dir / "smoke-test.json"
            if smoke_path.exists():
                smoke_errors = validate_smoke_evidence(
                    load_json(smoke_path),
                    plan,
                    str(team_wrapper.get("plan_digest", "")),
                    project_root=root,
                    state=state,
                )
                errors.extend(f"smoke: {item}" for item in smoke_errors)
            elif args.require_smoke:
                errors.append("smoke-test.json is required but missing")
            else:
                warnings.append("behavioral smoke evidence is not present; run validate_smoke.py before claiming delegation is proven")
            expected_profiles = {f"{agent['id']}.toml" for agent in plan["agents"]}
            profiles_dir = root / defaults["agent_profile_directory"]
            for agent in plan["agents"]:
                profile = profiles_dir / f"{agent['id']}.toml"
                if not profile.exists():
                    errors.append(f"missing agent profile: {profile}")
                elif "Managed by universal-codex-multi-agent-workspace" not in profile.read_text(encoding="utf-8")[:512]:
                    errors.append(f"unmanaged agent profile collision: {profile}")
                agent_state = state.get("agents", {}).get(agent["id"], {}) if isinstance(state.get("agents"), dict) else {}
                path = agent_state.get("path") if isinstance(agent_state, dict) else None
                if not path:
                    errors.append(f"missing workspace path in state for {agent['id']}")
                    continue
                if not Path(path).exists():
                    errors.append(f"workspace path does not exist for {agent['id']}: {path}")
                if agent["worktree"]:
                    record = worktrees.get(canonical_path(path))
                    if not record:
                        errors.append(f"workspace is not a registered Git worktree for {agent['id']}: {path}")
                    elif record.get("branch") != f"refs/heads/{agent['branch']}":
                        errors.append(f"worktree branch mismatch for {agent['id']}")
                if state.get("backend") != "none":
                    if not agent_state.get("thread_id"):
                        errors.append(f"missing initialized thread ID for {agent['id']}")
                    if agent_state.get("model") in (None, "auto") or agent_state.get("effort") in (None, "auto"):
                        errors.append(f"unresolved model routing for {agent['id']}")
            if profiles_dir.exists():
                stale = [path.name for path in profiles_dir.glob("*.toml") if path.name not in expected_profiles and "Managed by universal-codex-multi-agent-workspace" in path.read_text(encoding="utf-8")[:512]]
                if stale:
                    warnings.append("stale managed profiles were preserved: " + ", ".join(sorted(stale)))
        result = {
            "status": "pass" if not errors else "fail",
            "project_root": str(root),
            "backend": state.get("backend"),
            "errors": errors,
            "warnings": warnings,
        }
        write_output(result, args.output)
        return 0 if not errors else 1
    except (UcmawError, OSError) as exc:
        write_output({"status": "fail", "errors": [str(exc)], "warnings": warnings}, args.output)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
