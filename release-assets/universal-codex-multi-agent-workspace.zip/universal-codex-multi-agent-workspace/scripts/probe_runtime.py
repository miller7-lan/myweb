#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))

from ucmaw.common import UcmawError, canonical_path, resolve_git_root, write_output
from ucmaw.orchestrator import load_defaults
from ucmaw.rpc import (
    AppServerClient,
    DaemonRpcClient,
    RpcError,
    codex_version,
    discover_daemon_target,
    extract_model_catalog,
    is_loopback_endpoint,
)


def compact_models(catalog: list[dict[str, Any]]) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    for model in catalog:
        model_id = model.get("model") or model.get("id")
        if not model_id:
            continue
        efforts: list[str] = []
        for item in model.get("supportedReasoningEfforts", []):
            if isinstance(item, str):
                efforts.append(item)
            elif isinstance(item, dict):
                value = item.get("reasoningEffort") or item.get("effort")
                if isinstance(value, str):
                    efforts.append(value)
        output.append(
            {
                "model": model_id,
                "display_name": model.get("displayName"),
                "description": model.get("description"),
                "is_default": bool(model.get("isDefault")),
                "hidden": bool(model.get("hidden")),
                "default_effort": model.get("defaultReasoningEffort"),
                "supported_efforts": efforts,
            }
        )
    return output


def main() -> int:
    parser = argparse.ArgumentParser(description="Read-only capability probe for CodexMonitor and Codex app-server")
    parser.add_argument("--project-root", default=".")
    parser.add_argument("--output")
    parser.add_argument("--allow-remote-daemon", action="store_true")
    args = parser.parse_args()
    try:
        root = resolve_git_root(args.project_root)
        defaults = load_defaults()
        result: dict[str, Any] = {
            "schema_version": 1,
            "project_root": str(root),
            "codex_version": codex_version(),
            "preferred_backend": None,
            "daemon": {"available": False},
            "app_server": {"available": False},
        }
        target = discover_daemon_target(defaults["daemon"]["default_host"])
        result["daemon"]["target"] = target.public()
        if not is_loopback_endpoint(target.host) and not args.allow_remote_daemon:
            result["daemon"]["error"] = "non-loopback endpoint requires explicit opt-in"
        else:
            try:
                with DaemonRpcClient(target, float(defaults["daemon"]["timeout_seconds"])) as client:
                    result["daemon"]["ping"] = client.call("ping", {})
                    try:
                        result["daemon"]["info"] = client.call("daemon_info", {})
                    except RpcError:
                        result["daemon"]["info"] = {"version": "unknown"}
                    listed = client.call("list_workspaces", {})
                    workspaces = listed if isinstance(listed, list) else []
                    result["daemon"]["workspace_registered"] = any(
                        isinstance(item, dict)
                        and isinstance(item.get("path"), str)
                        and canonical_path(item["path"]) == canonical_path(root)
                        for item in workspaces
                    )
                    result["daemon"]["available"] = True
                    result["preferred_backend"] = "codexmonitor-daemon"
            except RpcError as exc:
                result["daemon"]["error"] = str(exc)
        try:
            with AppServerClient(timeout=float(defaults["app_server"]["request_timeout_seconds"])) as client:
                catalog = client.models()
                skills = client.skills(root)
                result["app_server"].update(
                    {
                        "available": True,
                        "models": compact_models(catalog),
                        "skills_list_available": skills is not None,
                    }
                )
                if result["preferred_backend"] is None:
                    result["preferred_backend"] = "codex-app-server"
        except RpcError as exc:
            result["app_server"]["error"] = str(exc)
        if result["preferred_backend"] is None:
            result["preferred_backend"] = "computer-use"
        write_output(result, args.output)
        return 0
    except UcmawError as exc:
        write_output({"status": "error", "error": str(exc)}, args.output)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
