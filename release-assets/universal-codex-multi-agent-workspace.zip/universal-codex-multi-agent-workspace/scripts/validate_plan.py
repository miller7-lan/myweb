#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from ucmaw.common import UcmawError, load_json, write_output
from ucmaw.plan import plan_digest, validate_plan


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate a Universal Codex multi-agent team plan")
    parser.add_argument("--plan", required=True)
    parser.add_argument("--project-root")
    parser.add_argument("--output")
    parser.add_argument("--max-agents", type=int, default=12)
    args = parser.parse_args()
    try:
        plan = load_json(args.plan)
        errors = validate_plan(plan, project_root=args.project_root, max_agents=args.max_agents)
        result = {
            "status": "valid" if not errors else "invalid",
            "plan": str(Path(args.plan).resolve()),
            "plan_digest": plan_digest(plan) if not errors else None,
            "errors": errors,
        }
        write_output(result, args.output)
        return 0 if not errors else 1
    except (UcmawError, json.JSONDecodeError) as exc:
        write_output({"status": "error", "errors": [str(exc)]}, args.output)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
