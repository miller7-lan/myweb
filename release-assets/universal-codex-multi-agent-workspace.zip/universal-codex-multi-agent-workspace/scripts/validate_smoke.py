#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from ucmaw.common import UcmawError, load_json, resolve_git_root, write_output
from ucmaw.evidence import validate_smoke_evidence


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate behavioral multi-agent delegation smoke evidence")
    parser.add_argument("--project-root", default=".")
    parser.add_argument("--evidence")
    parser.add_argument("--output")
    args = parser.parse_args()
    try:
        root = resolve_git_root(args.project_root)
        state_dir = root / ".codex" / "multi-agent"
        team = load_json(state_dir / "team.json")
        if not isinstance(team, dict) or not isinstance(team.get("plan"), dict):
            raise UcmawError("Provisioned team.json is missing or invalid")
        evidence_path = Path(args.evidence).resolve() if args.evidence else state_dir / "smoke-test.json"
        evidence = load_json(evidence_path)
        state = load_json(state_dir / "state.json")
        errors = validate_smoke_evidence(
            evidence,
            team["plan"],
            str(team.get("plan_digest", "")),
            project_root=root,
            state=state if isinstance(state, dict) else None,
        )
        result = {
            "status": "pass" if not errors else "fail",
            "project_root": str(root),
            "evidence": str(evidence_path),
            "errors": errors,
        }
        write_output(result, args.output)
        return 0 if not errors else 1
    except (UcmawError, OSError) as exc:
        write_output({"status": "error", "errors": [str(exc)]}, args.output)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
