"""Runtime helpers for the Universal Codex Multi-Agent Workspace Skill."""

__version__ = "1.0.0"
