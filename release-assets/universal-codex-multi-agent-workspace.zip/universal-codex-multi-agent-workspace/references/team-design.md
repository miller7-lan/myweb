# Dynamic team design

Use the discovery and runtime reports as evidence. Design roles from the project, never from a fixed roster.

## Decide whether a specialist earns a slot

Create a specialist only when it has a distinct responsibility, ownership boundary, validation surface, or tool/context need that can be delegated without making integration harder. Prefer the smallest team that covers the work. Read-only exploration can share the main checkout; writing roles normally receive a worktree.

Potential evidence includes repository boundaries, independently deployable packages, language/toolchain differences, critical data or security boundaries, platform-specific code, test ownership, release constraints, and large documentation or migration surfaces. These are signals, not required agent types.

## Orchestrator

Exactly one agent has `kind: "main"`. Name and describe it as an Orchestrator, not Main/Solver, lead developer, or another hybrid execution role. It owns decomposition, task briefs, dependency ordering, dispatch, conflict resolution, integration, final validation, and user communication.

Delegation is mandatory when a specialist covers the work. The Orchestrator must not write implementation, generate specialist deliverables, or perform the specialist's validation merely because doing so is faster. Its broad integration authority is not implementation ownership.

Before specialist-owned work begins, the Orchestrator must:

1. create a distinct task brief under `.codex/multi-agent/tasks/`;
2. send it through Codex subagent collaboration or the specialist's recorded persistent thread;
3. wait for and inspect the handoff;
4. accept, reject, or issue a bounded follow-up;
5. synthesize only after all required handoffs arrive.

Creating a worktree or idle sidebar thread does not satisfy this gate. If no dispatch transport is available, the Orchestrator stops with `DELEGATION_UNAVAILABLE`; it does not take over the specialist's work.

Use `any-delegation` unless the identity of an existing persistent thread is itself a requirement. If `persistent-thread` is selected, an unavailable peer-thread tool is reported as `PERSISTENT_THREAD_UNAVAILABLE`; do not count a newly spawned substitute as a pass.

## Specialists

Each specialist needs:

- a concise mission and non-overlapping responsibilities;
- concrete owned paths or globs plus explicit exclusions;
- write/read-only and worktree decisions;
- dependencies and handoff expectations;
- an exact model and supported reasoning effort selected from the runtime catalog;
- a reason for that routing based on task complexity, latency, and validation risk.

Use high reasoning for ambiguous integration or hard correctness work, medium for ordinary implementation and review, and low for narrow repeatable work—but only if the selected runtime model advertises that effort.

## Ownership

Exclusive owners may not claim the same literal path or nested directory. Shared ownership must be deliberate and usually read-only. Main may integrate across specialist paths, but should avoid concurrent edits while a specialist task is active.

## Team-size guardrail

The default maximum is six agents including Main. Exceed it only when the repository presents more than five truly independent work lanes and the user accepts the extra coordination/token cost.
