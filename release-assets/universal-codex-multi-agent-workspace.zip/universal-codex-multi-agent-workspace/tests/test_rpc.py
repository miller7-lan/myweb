from __future__ import annotations

import json
import queue
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

SKILL_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL_ROOT / "scripts"))

from ucmaw.rpc import DaemonRpcClient, DaemonTarget, resolve_model_effort


class FakeReader:
    def __init__(self, lines: queue.Queue[str]):
        self.lines = lines

    def readline(self) -> str:
        return self.lines.get(timeout=2)

    def close(self) -> None:
        return None


class FakeSocket:
    def __init__(self):
        self.lines: queue.Queue[str] = queue.Queue()

    def settimeout(self, timeout: float) -> None:
        return None

    def makefile(self, *args, **kwargs) -> FakeReader:
        return FakeReader(self.lines)

    def sendall(self, raw: bytes) -> None:
        message = json.loads(raw)
        if message["method"] == "auth":
            if message.get("params", {}).get("token") != "test-token":
                raise AssertionError("bad auth")
            self._write({"id": message["id"], "result": {"ok": True}})
        elif message["method"] == "ping":
            self._write({"method": "app-server-event", "params": {"ignored": True}})
            self._write({"id": message["id"], "result": {"ok": True}})

    def _write(self, value: dict) -> None:
        self.lines.put(json.dumps(value) + "\n")

    def close(self) -> None:
        return None


class RpcTests(unittest.TestCase):
    def test_daemon_auth_and_notification_skipping(self) -> None:
        target = DaemonTarget("127.0.0.1:4732", "test-token", "test")
        with patch("ucmaw.rpc.socket.create_connection", return_value=FakeSocket()):
            with DaemonRpcClient(target, timeout=2) as client:
                self.assertEqual(client.call("ping", {}), {"ok": True})

    def test_runtime_model_and_effort_fallback(self) -> None:
        catalog = [
            {
                "model": "available-model",
                "isDefault": True,
                "hidden": False,
                "defaultReasoningEffort": "medium",
                "supportedReasoningEfforts": [
                    {"reasoningEffort": "low"},
                    {"reasoningEffort": "medium"},
                ],
            }
        ]
        model, effort, warnings = resolve_model_effort("missing-model", "high", catalog)
        self.assertEqual((model, effort), ("available-model", "medium"))
        self.assertEqual(len(warnings), 2)


if __name__ == "__main__":
    unittest.main()
