from __future__ import annotations

import ipaddress
import json
import os
import plistlib
import queue
import shutil
import socket
import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlparse

from .common import UcmawError, canonical_path, load_json, run


class RpcError(UcmawError):
    pass


def _split_host_port(value: str) -> tuple[str, int]:
    raw = value.strip()
    if "://" not in raw:
        raw = "tcp://" + raw
    parsed = urlparse(raw)
    if not parsed.hostname or not parsed.port:
        raise RpcError(f"Invalid CodexMonitor daemon endpoint: {value}")
    return parsed.hostname, parsed.port


def is_loopback_endpoint(value: str) -> bool:
    try:
        host, _ = _split_host_port(value)
    except RpcError:
        return False
    if host.casefold() == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def _codexmonitor_app_bundles() -> list[tuple[str, Path]]:
    roots = [Path("/Applications"), Path.home() / "Applications"]
    bundles: list[tuple[str, Path]] = []
    for root in roots:
        if not root.is_dir():
            continue
        for app in root.glob("*Codex*Monitor*.app"):
            plist_path = app / "Contents" / "Info.plist"
            try:
                with plist_path.open("rb") as handle:
                    identifier = plistlib.load(handle).get("CFBundleIdentifier")
            except (OSError, plistlib.InvalidFileException):
                continue
            if isinstance(identifier, str) and identifier:
                bundles.append((identifier, app))
    return bundles


def _codexmonitor_identifiers() -> list[str]:
    identifiers = ["com.dimillian.codexmonitor"]
    identifiers.extend(identifier for identifier, _ in _codexmonitor_app_bundles())
    return list(dict.fromkeys(identifiers))


def _codexmonitor_settings_candidates() -> list[Path]:
    home = Path.home()
    candidates: list[Path] = []
    for identifier in _codexmonitor_identifiers():
        candidates.extend(
            [
                home / "Library" / "Application Support" / identifier / "settings.json",
                home / ".local" / "share" / identifier / "settings.json",
            ]
        )
        if os.environ.get("XDG_DATA_HOME"):
            candidates.append(Path(os.environ["XDG_DATA_HOME"]) / identifier / "settings.json")
        for variable in ("APPDATA", "LOCALAPPDATA"):
            if os.environ.get(variable):
                candidates.append(Path(os.environ[variable]) / identifier / "settings.json")
    unique: list[Path] = []
    seen: set[str] = set()
    for candidate in candidates:
        key = canonical_path(candidate)
        if key not in seen:
            seen.add(key)
            unique.append(candidate)
    return unique


@dataclass
class DaemonTarget:
    host: str
    token: str | None
    source: str
    settings_path: str | None = None

    def public(self) -> dict[str, Any]:
        return {
            "host": self.host,
            "source": self.source,
            "settings_path": self.settings_path,
            "token_configured": bool(self.token),
        }


def discover_daemon_target(default_host: str = "127.0.0.1:4732") -> DaemonTarget:
    env_host = os.environ.get("CODEX_MONITOR_DAEMON_HOST")
    env_token = os.environ.get("CODEX_MONITOR_DAEMON_TOKEN")
    if env_host or env_token:
        return DaemonTarget(env_host or default_host, env_token, "environment")

    for path in _codexmonitor_settings_candidates():
        settings = load_json(path, default=None)
        if not isinstance(settings, dict):
            continue
        host = settings.get("remoteBackendHost") or default_host
        token = settings.get("remoteBackendToken")
        targets = settings.get("remoteBackends")
        active_id = settings.get("activeRemoteBackendId")
        if isinstance(targets, list) and targets:
            active = next(
                (item for item in targets if isinstance(item, dict) and item.get("id") == active_id),
                None,
            )
            if active is None:
                active = next((item for item in targets if isinstance(item, dict)), None)
            if active:
                host = active.get("host") or host
                token = active.get("token") if active.get("token") is not None else token
        return DaemonTarget(str(host), str(token) if token else None, "codexmonitor-settings", str(path))
    return DaemonTarget(default_host, None, "default")


def _daemon_tools_for_target(target: DaemonTarget) -> tuple[Path | None, Path | None]:
    controller = shutil.which("codex_monitor_daemonctl") or shutil.which("codex-monitor-daemonctl")
    daemon = shutil.which("codex_monitor_daemon") or shutil.which("codex-monitor-daemon")
    bundle_candidates = _codexmonitor_app_bundles()
    if target.settings_path:
        identifier = Path(target.settings_path).parent.name
        bundle_candidates.sort(key=lambda item: item[0] != identifier)
    for _, bundle in bundle_candidates:
        macos = bundle / "Contents" / "MacOS"
        if controller is None and (macos / "codex_monitor_daemonctl").is_file():
            controller = str(macos / "codex_monitor_daemonctl")
        if daemon is None and (macos / "codex_monitor_daemon").is_file():
            daemon = str(macos / "codex_monitor_daemon")
    return Path(controller) if controller else None, Path(daemon) if daemon else None


def start_configured_daemon(target: DaemonTarget, timeout: float = 15) -> dict[str, Any]:
    if not target.token:
        return {"attempted": False, "reason": "no configured daemon token"}
    controller, daemon = _daemon_tools_for_target(target)
    if controller is None:
        return {"attempted": False, "reason": "daemon controller not installed"}
    arguments = [str(controller), "start", "--json"]
    if target.settings_path:
        arguments.extend(["--data-dir", str(Path(target.settings_path).parent)])
    if daemon is not None:
        arguments.extend(["--daemon-path", str(daemon)])
    result = run(arguments, check=False, timeout=timeout)
    if result.returncode != 0:
        return {"attempted": True, "started": False, "reason": "daemon controller start failed"}
    try:
        payload = json.loads(result.stdout)
    except json.JSONDecodeError:
        payload = {}
    return {
        "attempted": True,
        "started": payload.get("state") == "running" or bool(payload.get("pid")),
        "state": payload.get("state"),
        "pid": payload.get("pid"),
    }


def codexmonitor_workspace_registry(paths: list[Path | str]) -> dict[str, Any]:
    targets = {canonical_path(path) for path in paths}
    registered: set[str] = set()
    checked: list[str] = []
    for settings_path in _codexmonitor_settings_candidates():
        workspace_path = settings_path.with_name("workspaces.json")
        if not workspace_path.exists():
            continue
        checked.append(str(workspace_path))
        value = load_json(workspace_path, default={})
        items: list[Any]
        if isinstance(value, dict):
            items = list(value.values())
        elif isinstance(value, list):
            items = value
        else:
            items = []
        for item in items:
            if isinstance(item, dict) and isinstance(item.get("path"), str):
                registered.add(canonical_path(item["path"]))
    missing = sorted(targets - registered)
    return {
        "registry_files_checked": checked,
        "all_registered": bool(checked) and not missing,
        "registered_count": len(targets & registered),
        "target_count": len(targets),
        "missing_count": len(missing),
    }


class DaemonRpcClient:
    def __init__(self, target: DaemonTarget, timeout: float = 4):
        self.target = target
        self.timeout = timeout
        self._socket: socket.socket | None = None
        self._reader: Any = None
        self._next_id = 1

    def __enter__(self) -> "DaemonRpcClient":
        host, port = _split_host_port(self.target.host)
        try:
            self._socket = socket.create_connection((host, port), timeout=self.timeout)
            self._socket.settimeout(self.timeout)
            self._reader = self._socket.makefile("r", encoding="utf-8", newline="\n")
        except OSError as exc:
            raise RpcError(f"CodexMonitor daemon is unreachable at {self.target.host}: {exc}") from exc
        if self.target.token:
            self.call("auth", {"token": self.target.token})
        return self

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        if self._reader is not None:
            self._reader.close()
        if self._socket is not None:
            self._socket.close()
        self._reader = None
        self._socket = None

    def call(self, method: str, params: Any = None) -> Any:
        if self._socket is None or self._reader is None:
            raise RpcError("CodexMonitor daemon client is not connected")
        request_id = self._next_id
        self._next_id += 1
        payload: dict[str, Any] = {"id": request_id, "method": method}
        if params is not None:
            payload["params"] = params
        encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n"
        try:
            self._socket.sendall(encoded.encode("utf-8"))
            deadline = time.monotonic() + self.timeout
            while time.monotonic() < deadline:
                line = self._reader.readline()
                if not line:
                    raise RpcError("CodexMonitor daemon closed the connection")
                message = json.loads(line)
                if message.get("id") != request_id:
                    continue
                if "error" in message:
                    error = message["error"]
                    detail = error.get("message", str(error)) if isinstance(error, dict) else str(error)
                    raise RpcError(f"CodexMonitor {method} failed: {detail}")
                return message.get("result")
        except (OSError, json.JSONDecodeError) as exc:
            raise RpcError(f"CodexMonitor {method} transport failed: {exc}") from exc
        raise RpcError(f"CodexMonitor {method} timed out")


class AppServerClient:
    def __init__(self, codex_bin: str = "codex", timeout: float = 20):
        self.codex_bin = codex_bin
        self.timeout = timeout
        self.process: subprocess.Popen[str] | None = None
        self._next_id = 1
        self._messages: queue.Queue[Any] = queue.Queue()
        self._backlog: list[dict[str, Any]] = []
        self._reader_thread: threading.Thread | None = None
        self._stderr_thread: threading.Thread | None = None
        self._stderr_tail: list[str] = []

    def __enter__(self) -> "AppServerClient":
        try:
            self.process = subprocess.Popen(
                [self.codex_bin, "app-server", "--stdio"],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
            )
        except OSError as exc:
            raise RpcError(f"Could not start codex app-server: {exc}") from exc
        self._reader_thread = threading.Thread(target=self._read_loop, daemon=True)
        self._reader_thread.start()
        self._stderr_thread = threading.Thread(target=self._read_stderr, daemon=True)
        self._stderr_thread.start()
        self.initialize()
        return self

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        process = self.process
        if process is None:
            return
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=3)
        self.process = None

    def _read_loop(self) -> None:
        assert self.process is not None and self.process.stdout is not None
        try:
            for line in self.process.stdout:
                stripped = line.strip()
                if not stripped:
                    continue
                try:
                    self._messages.put(json.loads(stripped))
                except json.JSONDecodeError:
                    continue
        finally:
            self._messages.put({"_eof": True})

    def _read_stderr(self) -> None:
        assert self.process is not None and self.process.stderr is not None
        for line in self.process.stderr:
            stripped = line.strip()
            if stripped:
                self._stderr_tail.append(stripped)
                del self._stderr_tail[:-20]

    def _exit_detail(self) -> str:
        return "; ".join(self._stderr_tail[-5:]) or "no diagnostic output"

    def _send(self, message: dict[str, Any]) -> None:
        if self.process is None or self.process.stdin is None or self.process.poll() is not None:
            raise RpcError("codex app-server is not running")
        try:
            self.process.stdin.write(json.dumps(message, ensure_ascii=False, separators=(",", ":")) + "\n")
            self.process.stdin.flush()
        except OSError as exc:
            raise RpcError(f"codex app-server write failed: {exc}") from exc

    def notify(self, method: str, params: Any = None) -> None:
        message: dict[str, Any] = {"method": method}
        if params is not None:
            message["params"] = params
        self._send(message)

    def _handle_server_request(self, message: dict[str, Any]) -> None:
        if "method" in message and "id" in message:
            self._send(
                {
                    "id": message["id"],
                    "error": {"code": -32601, "message": "Initialization client does not approve interactive requests"},
                }
            )

    def request(self, method: str, params: Any = None, timeout: float | None = None) -> Any:
        request_id = self._next_id
        self._next_id += 1
        message: dict[str, Any] = {"id": request_id, "method": method}
        if params is not None:
            message["params"] = params
        self._send(message)
        deadline = time.monotonic() + (timeout or self.timeout)
        while time.monotonic() < deadline:
            remaining = max(0.01, deadline - time.monotonic())
            try:
                response = self._messages.get(timeout=remaining)
            except queue.Empty as exc:
                raise RpcError(f"codex app-server {method} timed out") from exc
            if response.get("_eof"):
                raise RpcError(f"codex app-server exited while handling {method}: {self._exit_detail()}")
            if response.get("id") == request_id and "method" not in response:
                if "error" in response:
                    error = response["error"]
                    detail = error.get("message", str(error)) if isinstance(error, dict) else str(error)
                    raise RpcError(f"codex app-server {method} failed: {detail}")
                return response.get("result")
            if "method" in response and "id" in response:
                self._handle_server_request(response)
            else:
                self._backlog.append(response)
        raise RpcError(f"codex app-server {method} timed out")

    def wait_notification(
        self,
        method: str,
        predicate: Callable[[dict[str, Any]], bool] | None = None,
        timeout: float = 90,
    ) -> dict[str, Any]:
        predicate = predicate or (lambda _: True)
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            for index, message in enumerate(self._backlog):
                if message.get("method") == method and predicate(message):
                    return self._backlog.pop(index)
            remaining = max(0.01, deadline - time.monotonic())
            try:
                message = self._messages.get(timeout=remaining)
            except queue.Empty as exc:
                raise RpcError(f"Timed out waiting for app-server notification {method}") from exc
            if message.get("_eof"):
                raise RpcError(f"codex app-server exited before {method}: {self._exit_detail()}")
            if "method" in message and "id" in message:
                self._handle_server_request(message)
            elif message.get("method") == method and predicate(message):
                return message
            else:
                self._backlog.append(message)
        raise RpcError(f"Timed out waiting for app-server notification {method}")

    def initialize(self) -> None:
        self.request(
            "initialize",
            {
                "clientInfo": {
                    "name": "universal_codex_multi_agent_workspace",
                    "title": "Universal Codex Multi-Agent Workspace",
                    "version": "1.0.0",
                }
            },
        )
        self.notify("initialized", {})

    def models(self) -> list[dict[str, Any]]:
        result = self.request("model/list", {})
        return extract_model_catalog(result)

    def skills(self, cwd: Path | str) -> Any:
        return self.request("skills/list", {"cwds": [str(Path(cwd).resolve())], "forceReload": True})

    def start_thread(self, cwd: Path | str, model: str | None = None) -> str:
        params: dict[str, Any] = {"cwd": str(Path(cwd).resolve()), "approvalPolicy": "on-request"}
        if model:
            params["model"] = model
        result = self.request("thread/start", params)
        thread_id = extract_thread_id(result)
        if not thread_id:
            raise RpcError("codex app-server thread/start returned no thread ID")
        return thread_id

    def resume_thread(self, thread_id: str) -> None:
        self.request("thread/resume", {"threadId": thread_id})

    def set_thread_name(self, thread_id: str, name: str) -> None:
        self.request("thread/name/set", {"threadId": thread_id, "name": name})

    def initialize_turn(
        self,
        thread_id: str,
        cwd: Path | str,
        prompt: str,
        model: str,
        effort: str,
        timeout: float = 90,
    ) -> str | None:
        result = self.request(
            "turn/start",
            {
                "threadId": thread_id,
                "input": [{"type": "text", "text": prompt}],
                "cwd": str(Path(cwd).resolve()),
                "approvalPolicy": "on-request",
                "sandboxPolicy": {"type": "readOnly"},
                "model": model,
                "effort": effort,
            },
        )
        turn_id = extract_turn_id(result)
        if turn_id:
            self.wait_notification(
                "turn/completed",
                lambda message: _notification_turn_id(message) == turn_id,
                timeout=timeout,
            )
        return turn_id


def _notification_turn_id(message: dict[str, Any]) -> str | None:
    params = message.get("params")
    if not isinstance(params, dict):
        return None
    if isinstance(params.get("turn"), dict):
        return params["turn"].get("id")
    return params.get("turnId")


def extract_thread_id(value: Any) -> str | None:
    if isinstance(value, dict):
        thread = value.get("thread")
        if isinstance(thread, dict) and isinstance(thread.get("id"), str):
            return thread["id"]
        if isinstance(value.get("threadId"), str):
            return value["threadId"]
        if value.get("object") == "thread" and isinstance(value.get("id"), str):
            return value["id"]
    return None


def extract_turn_id(value: Any) -> str | None:
    if isinstance(value, dict):
        turn = value.get("turn")
        if isinstance(turn, dict) and isinstance(turn.get("id"), str):
            return turn["id"]
        if isinstance(value.get("turnId"), str):
            return value["turnId"]
    return None


def extract_model_catalog(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, dict) and isinstance(value.get("data"), list):
        return [item for item in value["data"] if isinstance(item, dict)]
    if isinstance(value, list):
        return [item for item in value if isinstance(item, dict)]
    return []


def _model_id(model: dict[str, Any]) -> str | None:
    for key in ("model", "id"):
        if isinstance(model.get(key), str) and model[key]:
            return model[key]
    return None


def _efforts(model: dict[str, Any]) -> list[str]:
    raw = model.get("supportedReasoningEfforts") or model.get("supported_reasoning_efforts") or []
    values: list[str] = []
    for item in raw:
        if isinstance(item, str):
            values.append(item)
        elif isinstance(item, dict):
            value = item.get("reasoningEffort") or item.get("reasoning_effort") or item.get("effort")
            if isinstance(value, str):
                values.append(value)
    return values


def resolve_model_effort(
    requested_model: str,
    requested_effort: str,
    catalog: list[dict[str, Any]],
) -> tuple[str, str, list[str]]:
    warnings: list[str] = []
    visible = [item for item in catalog if not item.get("hidden") and _model_id(item)] or [item for item in catalog if _model_id(item)]
    if not visible:
        if requested_model == "auto" or requested_effort == "auto":
            raise RpcError("Runtime model catalog is empty; explicit model and effort are required")
        return requested_model, requested_effort, warnings
    by_id = {_model_id(item): item for item in visible}
    default = next((item for item in visible if item.get("isDefault") or item.get("is_default")), visible[0])
    if requested_model == "auto" or requested_model not in by_id:
        selected = default
        if requested_model != "auto":
            warnings.append(f"model {requested_model!r} unavailable; used runtime default {_model_id(selected)!r}")
    else:
        selected = by_id[requested_model]
    model_id = _model_id(selected)
    assert model_id is not None
    efforts = _efforts(selected)
    default_effort = selected.get("defaultReasoningEffort") or selected.get("default_reasoning_effort")
    if requested_effort == "auto":
        effort = default_effort or (efforts[0] if efforts else "medium")
    elif efforts and requested_effort not in efforts:
        effort = default_effort or efforts[0]
        warnings.append(f"effort {requested_effort!r} unsupported by {model_id!r}; used {effort!r}")
    else:
        effort = requested_effort
    return model_id, str(effort), warnings


def codex_version(codex_bin: str = "codex") -> str | None:
    result = run([codex_bin, "--version"], check=False)
    return result.stdout.strip() if result.returncode == 0 else None
