# Profiles

This directory documents profile intent for Skill maintainers. Runtime project profiles are generated from the validated team plan into the target repository's `.codex/agents/` directory using the official custom-agent TOML format.

No fixed agent profiles are bundled: predefining roles here would defeat project discovery and dynamic team design.
