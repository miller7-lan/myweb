from __future__ import annotations

from pathlib import Path, PurePosixPath
from typing import Any

from .common import MANAGED_BY


TRANSPORT_REQUIREMENTS = {"any-delegation", "persistent-thread"}
TRANSPORTS = {"persistent-thread", "subagent"}


def _nonempty(value: Any, label: str, errors: list[str]) -> bool:
    if not isinstance(value, str) or not value.strip():
        errors.append(f"{label} must be a non-empty string")
        return False
    return True


def validate_smoke_evidence(
    evidence: Any,
    plan: dict[str, Any],
    plan_hash: str,
    project_root: Path | str | None = None,
    state: dict[str, Any] | None = None,
) -> list[str]:
    errors: list[str] = []
    if not isinstance(evidence, dict):
        return ["smoke evidence must be a JSON object"]
    if evidence.get("managed_by") != MANAGED_BY:
        errors.append(f"managed_by must be {MANAGED_BY}")
    if evidence.get("version") != 1:
        errors.append("version must be 1")
    if evidence.get("plan_digest") != plan_hash:
        errors.append("plan_digest does not match the provisioned team")

    requested = evidence.get("requested_transport")
    if requested not in TRANSPORT_REQUIREMENTS:
        errors.append("requested_transport must be any-delegation or persistent-thread")

    assignments = evidence.get("assignments")
    if not isinstance(assignments, list) or len(assignments) < 2:
        errors.append("assignments must contain at least two completed specialist assignments")
        assignments = []

    agents = {
        agent["id"]: agent
        for agent in plan.get("agents", [])
        if isinstance(agent, dict) and isinstance(agent.get("id"), str)
    }
    task_ids: list[str] = []
    agent_ids: list[str] = []
    root = Path(project_root).resolve() if project_root is not None else None
    for index, assignment in enumerate(assignments):
        label = f"assignments[{index}]"
        if not isinstance(assignment, dict):
            errors.append(f"{label} must be an object")
            continue
        task_id = assignment.get("task_id")
        agent_id = assignment.get("agent_id")
        if _nonempty(task_id, f"{label}.task_id", errors):
            task_ids.append(task_id)
        if _nonempty(agent_id, f"{label}.agent_id", errors):
            agent_ids.append(agent_id)
            if agent_id not in agents:
                errors.append(f"{label}.agent_id is not in the provisioned team: {agent_id}")
            elif agents[agent_id].get("kind") != "specialist":
                errors.append(f"{label}.agent_id must name a specialist")

        brief_path = assignment.get("brief_path")
        if _nonempty(brief_path, f"{label}.brief_path", errors):
            normalized = brief_path.replace("\\", "/")
            pure = PurePosixPath(normalized)
            if pure.is_absolute() or ".." in pure.parts:
                errors.append(f"{label}.brief_path must be project-relative without parent traversal")
            elif not normalized.startswith(".codex/multi-agent/tasks/"):
                errors.append(f"{label}.brief_path must be under .codex/multi-agent/tasks/")
            elif root is not None and not (root / pure).is_file():
                errors.append(f"{label}.brief_path does not exist: {brief_path}")

        transport = assignment.get("transport")
        if transport not in TRANSPORTS:
            errors.append(f"{label}.transport must be persistent-thread or subagent")
        if requested == "persistent-thread" and transport != "persistent-thread":
            errors.append(f"{label} did not use the required persistent-thread transport")
        _nonempty(assignment.get("dispatch_id"), f"{label}.dispatch_id", errors)
        _nonempty(assignment.get("completion_id"), f"{label}.completion_id", errors)
        if assignment.get("handoff_status") != "completed":
            errors.append(f"{label}.handoff_status must be completed")
        if transport == "persistent-thread":
            target_thread_id = assignment.get("target_thread_id")
            if _nonempty(target_thread_id, f"{label}.target_thread_id", errors) and state is not None:
                state_agents = state.get("agents") if isinstance(state.get("agents"), dict) else {}
                recorded = state_agents.get(agent_id, {}) if isinstance(agent_id, str) else {}
                recorded_thread = recorded.get("thread_id") if isinstance(recorded, dict) else None
                if recorded_thread != target_thread_id:
                    errors.append(f"{label}.target_thread_id does not match state.json for {agent_id}")
            _nonempty(assignment.get("wait_cursor"), f"{label}.wait_cursor", errors)
        elif transport == "subagent":
            _nonempty(assignment.get("child_agent_id"), f"{label}.child_agent_id", errors)

    if len(task_ids) != len(set(task_ids)):
        errors.append("task_id values must be unique")
    if len(agent_ids) != len(set(agent_ids)):
        errors.append("the smoke test must use distinct specialist agents")
    for field in ("waited_for_all", "final_check_after_all"):
        if evidence.get(field) is not True:
            errors.append(f"{field} must be true")
    for field in ("main_performed_specialist_work", "unauthorized_writes"):
        if evidence.get(field) is not False:
            errors.append(f"{field} must be false")
    if evidence.get("status") != "pass":
        errors.append("status must be pass")
    return errors
